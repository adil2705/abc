# Sans Traders - E-Commerce Platform

A complete e-commerce solution with Admin Panel, Customer Frontend, and PHP Backend.

## 🚀 System Requirements

### Core Dependencies
- **Node.js**: `v14.17.6` (Compatible with v14.x - v18.x)
- **PHP**: `v8.0.9` or higher
- **Database**: MySQL / MariaDB (via XAMPP/WAMP or standalone)
- **Web Server**: Apache (via XAMPP recommended for local dev)

---

## 🛠️ Installation & Setup

### 1. Backend Setup (PHP)

The backend powers the API and serves static assets.

1. **Place Code**: Ensure the project folder `sans_traders-master` is in your web server's root directory (e.g., `C:\xampp\htdocs\`).
2. **Database Import**:
   - Create a database named `u545525854_sanstraders` (or update `.env` to match yours).
   - Import the provided SQL files (e.g., `database_migration_orders.sql`, `hello.sql`) into your database.
3. **Configuration**:
   - Navigate to `backend/` and create/update the `.env` file:
   
   ```ini
   # backend/.env
   
   # Database Configuration
   DB_HOST=localhost
   DB_NAME=u545525854_sanstraders
   DB_USER=root
   DB_PASS=
   
   # JWT Configuration
   JWT_SECRET=your-production-secret-key-change-this
   
   # SMTP Configuration (For Emails)
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_EMAIL=your-email@gmail.com
   SMTP_PASSWORD=your-app-password
   SMTP_FROM_EMAIL=your-email@gmail.com
   SMTP_FROM_NAME=Sans Traders
   ADMIN_EMAIL=admin@example.com
   ```

4. **Media Folder Permissions**:
   - Ensure `media/uploads` is writable by the web server.
   - Windows: `icacls "media\uploads" /grant Everyone:F` (for local dev) or grant permissions to IUSR/IIS_IUSRS.

### 2. Frontend Setup (Customer App)

1. Navigate to `frontend/`:
   ```bash
   cd frontend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure Environment:
   - Create `.env` in `frontend/`:
   ```ini
   VITE_API_BASE_URL=http://localhost/sans_traders-master/backend/api
   ```
4. Start Development Server:
   ```bash
   npm run dev
   ```

### 3. Admin Setup (Dashboard)

1. Navigate to `admin/`:
   ```bash
   cd admin
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure Environment:
   - Create `.env` in `admin/`:
   ```ini
   VITE_API_BASE_URL=http://localhost/sans_traders-master/backend/api
   ```
4. Start Development Server:
   ```bash
   npm run dev
   ```

---

## 📦 Production Deployment Guide

### Backend (API)
1. **Server**: Deploy on a Linux server (Ubuntu/CentOS) with Apache/Nginx + PHP 8.0+.
2. **SSL**: Ensure HTTPS is enabled (Let's Encrypt).
3. **Database**: Use a managed database service (RDS, Cloud SQL) or secured local MySQL instance.
4. **Environment**:
   - Set `DB_HOST` to your production database host.
   - Change `JWT_SECRET` to a strong, random string.
   - Update `SMTP` credentials for production email service (e.g., SendGrid, SES or properly configured SMTP).

### Frontends (Admin & Customer)
1. **Build**: Run the build command for both apps:
   ```bash
   npm run build
   ```
   This generates a `dist/` folder in each project.
2. **Updates**:
   - Update `.env` files **before building** to point to the production API URL (e.g., `https://api.sanstraders.com`).
3. **Serving**:
   - Upload the contents of `dist/` to your web server (e.g., `public_html/` or `public_html/admin/`).
   - Configure your web server (Apache `.htaccess` or Nginx `nginx.conf`) to handle React Router (SPA) routing:

   **Apache .htaccess for SPA:**
   ```apache
   <IfModule mod_rewrite.c>
     RewriteEngine On
     RewriteBase /
     RewriteRule ^index\.html$ - [L]
     RewriteCond %{REQUEST_FILENAME} !-f
     RewriteCond %{REQUEST_FILENAME} !-d
     RewriteRule . /index.html [L]
   </IfModule>
   ```

---

## 📂 Project Structure

```
sans_traders-master/
├── admin/              # Admin Dashboard (React + Vite)
├── backend/            # API & Business Logic (PHP)
│   ├── api/            # API Endpoints
│   ├── config/         # Database & Core Config
│   └── utils/          # Helpers (Email, Uploads, etc.)
├── frontend/           # Customer Storefront (React + Vite)
└── media/              # Public Media Assets (Images)
```

## 🧪 Testing

- **API**: Test endpoints using Postman or local `tests/` scripts.
- **Frontend**: Manual testing flow:
  1. Login as Admin → Add Product → Upload Image.
  2. Visit Frontend → View Product → Add to Cart.
  3. Checkout → Verify Order in Admin.
