import React, { useRef, useEffect, useState } from 'react';
import { createPortal } from 'react-dom';

const OrderDetailsModal = ({ order, onClose, onStatusUpdate, onRefresh }) => {
    const modalRef = useRef(null);
    const [updating, setUpdating] = useState(false);

    // Close on click outside
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (modalRef.current && !modalRef.current.contains(event.target)) {
                onClose();
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [onClose]);

    // Prevent body scroll when modal is open
    useEffect(() => {
        document.body.style.overflow = 'hidden';
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, []);

    const handleStatusChange = async (newStatus) => {
        if (!onStatusUpdate) return;
        setUpdating(true);
        try {
            await onStatusUpdate(order.id, newStatus);
            // Wait a bit or manually update local state if needed
            if (onRefresh) onRefresh();
            onClose(); // Optional: close modal on update, or keep open and update local state
        } catch (error) {
            console.error("Failed to update status", error);
        } finally {
            setUpdating(false);
        }
    };

    if (!order) return null;

    const getStatusColor = (status) => {
        const colors = {
            pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
            confirmed: 'bg-blue-100 text-blue-800 border-blue-200',
            processing: 'bg-purple-100 text-purple-800 border-purple-200',
            shipped: 'bg-indigo-100 text-indigo-800 border-indigo-200',
            delivered: 'bg-green-100 text-green-800 border-green-200',
            cancelled: 'bg-red-100 text-red-800 border-red-200',
        };
        return colors[status] || 'bg-gray-100 text-gray-800 border-gray-200';
    };

    const modalContent = (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in">
            <div
                ref={modalRef}
                className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto transform transition-all animate-slide-up"
            >
                {/* Header */}
                <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex justify-between items-center z-10">
                    <div>
                        <div className="flex items-center gap-3">
                            <h2 className="text-xl font-bold text-gray-900">Order #{order.bill_no}</h2>
                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getStatusColor(order.order_status)}`}>
                                {order.order_status.toUpperCase()}
                            </span>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                            Placed on {new Date(order.date_time * 1000).toLocaleString()}
                        </p>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500 hover:text-gray-700"
                    >
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>

                <div className="p-6 space-y-8">
                    {/* Status Update Controls */}
                    <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                        <h3 className="text-sm font-semibold text-blue-900 mb-3">Update Order Status</h3>
                        <div className="flex flex-wrap gap-2">
                            {['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'].map((status) => (
                                <button
                                    key={status}
                                    onClick={() => handleStatusChange(status)}
                                    disabled={updating || order.order_status === status}
                                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors
                                        ${order.order_status === status
                                            ? 'bg-blue-600 text-white cursor-default ring-2 ring-blue-600 ring-offset-1'
                                            : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 hover:text-blue-600 hover:border-blue-300'
                                        }
                                        ${updating ? 'opacity-50 cursor-not-allowed' : ''}
                                    `}
                                >
                                    {status.charAt(0).toUpperCase() + status.slice(1)}
                                </button>
                            ))}
                        </div>
                    </div>
                    {/* Customer & Shipping Info Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Customer Details */}
                        <div className="bg-gray-50 rounded-lg p-5 border border-gray-100">
                            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                                <span className="text-lg">👤</span> Customer Details
                            </h3>
                            <div className="space-y-3">
                                <div className="flex gap-3">
                                    <div className="w-24 text-sm text-gray-500">Name</div>
                                    <div className="font-medium text-gray-900">{order.buyer_name || order.customer_name}</div>
                                </div>
                                <div className="flex gap-3">
                                    <div className="w-24 text-sm text-gray-500">Email</div>
                                    <div className="font-medium text-gray-900 break-all">{order.buyer_email || 'N/A'}</div>
                                </div>
                                <div className="flex gap-3">
                                    <div className="w-24 text-sm text-gray-500">Phone</div>
                                    <div className="font-medium text-gray-900">{order.buyer_phone || order.customer_phone || 'N/A'}</div>
                                </div>
                            </div>
                        </div>

                        {/* Shipping Details */}
                        <div className="bg-gray-50 rounded-lg p-5 border border-gray-100">
                            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                                <span className="text-lg">📍</span> Shipping Address
                            </h3>
                            <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                                {order.delivery_address}
                            </p>
                            {order.order_notes && (
                                <div className="mt-4 pt-4 border-t border-gray-200">
                                    <h4 className="text-xs font-semibold text-gray-500 mb-1">Order Notes</h4>
                                    <p className="text-sm text-gray-600 italic">"{order.order_notes}"</p>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Order Items */}
                    <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-4 px-1">Order Items ({order.items.length})</h3>
                        <div className="border border-gray-200 rounded-lg overflow-hidden bg-white shadow-sm">
                            <div className="overflow-x-auto">
                                <table className="w-full">
                                    <thead className="bg-gray-50 border-b border-gray-200">
                                        <tr>
                                            <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Product</th>
                                            <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">Price</th>
                                            <th className="px-6 py-3 text-center text-xs font-semibold text-gray-500 uppercase tracking-wider">Qty</th>
                                            <th className="px-6 py-3 text-right text-xs font-semibold text-gray-500 uppercase tracking-wider">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-200">
                                        {order.items.map((item, index) => (
                                            <tr key={index} className="hover:bg-gray-50 transition-colors">
                                                <td className="px-6 py-4">
                                                    <div className="flex items-center">
                                                        <div className="h-12 w-12 flex-shrink-0 bg-gray-100 rounded-md border border-gray-200 overflow-hidden">
                                                            {item.product_image ? (
                                                                <img
                                                                    src={`${import.meta.env.VITE_API_BASE_URL}/../../${item.product_image}`}
                                                                    alt={item.product_name}
                                                                    className="h-full w-full object-cover"
                                                                    onError={(e) => {
                                                                        e.target.onerror = null;
                                                                        e.target.src = 'https://placehold.co/100x100?text=No+Image';
                                                                    }}
                                                                />
                                                            ) : (
                                                                <div className="h-full w-full flex items-center justify-center text-gray-400">
                                                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                                                    </svg>
                                                                </div>
                                                            )}
                                                        </div>
                                                        <div className="ml-4">
                                                            <div className="text-sm font-medium text-gray-900">{item.product_name}</div>
                                                            <div className="text-xs text-gray-500">{item.product_sku || 'SKU: N/A'}</div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="px-6 py-4 text-sm text-gray-600">
                                                    ₹{parseFloat(item.rate).toFixed(2)}
                                                </td>
                                                <td className="px-6 py-4 text-center text-sm text-gray-600">
                                                    {item.qty}
                                                </td>
                                                <td className="px-6 py-4 text-right text-sm font-medium text-gray-900">
                                                    ₹{parseFloat(item.amount).toFixed(2)}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    {/* Order Summary */}
                    <div className="flex justify-end">
                        <div className="w-full md:w-1/3 bg-gray-50 rounded-lg p-5 border border-gray-100">
                            <h4 className="text-sm font-semibold text-gray-900 uppercase mb-4 text-right">Order Summary</h4>
                            <div className="space-y-3 text-sm">
                                <div className="flex justify-between text-gray-600">
                                    <span>Subtotal</span>
                                    <span>₹{parseFloat(order.gross_amount).toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between text-gray-600">
                                    <span>Service Charge ({order.service_charge_rate}%)</span>
                                    <span>₹{parseFloat(order.service_charge).toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between text-gray-600">
                                    <span>VAT ({order.vat_charge_rate}%)</span>
                                    <span>₹{parseFloat(order.vat_charge).toFixed(2)}</span>
                                </div>
                                <div className="border-t border-gray-200 pt-3 mt-3 flex justify-between font-bold text-lg text-gray-900">
                                    <span>Total</span>
                                    <span>₹{parseFloat(order.net_amount).toFixed(2)}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="sticky bottom-0 bg-gray-50 px-6 py-4 border-t border-gray-200 flex justify-end gap-3 z-10 rounded-b-xl">
                    <button
                        onClick={() => window.open(`${import.meta.env.VITE_API_BASE_URL}/orders/invoice.php?id=${order.id}`, '_blank')}
                        className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 font-medium transition-colors flex items-center gap-2"
                    >
                        <span>📄</span> Invoice
                    </button>
                    <button
                        onClick={onClose}
                        className="px-4 py-2 bg-white text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 font-medium transition-colors"
                    >
                        Close
                    </button>
                    {/* Add more action buttons here if needed, like "Print Invoice" or "Mark as Shipped" */}
                </div>
            </div>
        </div>
    );

    return createPortal(modalContent, document.body);
};

export default OrderDetailsModal;
