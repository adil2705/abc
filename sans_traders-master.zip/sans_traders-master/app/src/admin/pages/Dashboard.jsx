import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';

const Dashboard = () => {
    const [summary, setSummary] = useState(null);
    const [recentOrders, setRecentOrders] = useState([]);
    const [productSales, setProductSales] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchDashboardData();
    }, []);

    const fetchDashboardData = async () => {
        try {
            const [dashboardRes, salesRes] = await Promise.all([
                api.get('/admin/dashboard.php'),
                api.get('/reports/product-sales.php')
            ]);
            setSummary(dashboardRes.data.summary);
            setRecentOrders(dashboardRes.data.recent_orders);
            setProductSales(salesRes.data.sales);
        } catch (error) {
            console.error('Failed to fetch dashboard data:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center h-screen">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            </div>
        );
    }

    return (
        <div className="p-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-6">Dashboard</h1>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-8">
                <div className="stat-card bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-blue-100 text-sm font-medium">Today's Orders</p>
                            <p className="text-3xl font-bold mt-2">{summary?.today_orders || 0}</p>
                        </div>
                        <div className="bg-blue-400 bg-opacity-30 p-3 rounded-lg">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                            </svg>
                        </div>
                    </div>
                </div>

                <div className="stat-card bg-gradient-to-br from-green-500 to-green-600 text-white">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-green-100 text-sm font-medium">Today's Sales</p>
                            <p className="text-3xl font-bold mt-2">₹{summary?.today_sales?.toFixed(2) || '0.00'}</p>
                        </div>
                        <div className="bg-green-400 bg-opacity-30 p-3 rounded-lg">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                    </div>
                </div>

                <div className="stat-card bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-yellow-100 text-sm font-medium">Pending Orders</p>
                            <p className="text-3xl font-bold mt-2">{summary?.pending_orders || 0}</p>
                        </div>
                        <div className="bg-yellow-400 bg-opacity-30 p-3 rounded-lg">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                    </div>
                </div>

                <div className="stat-card bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-purple-100 text-sm font-medium">Total Buyers</p>
                            <p className="text-3xl font-bold mt-2">{summary?.total_buyers || 0}</p>
                        </div>
                        <div className="bg-purple-400 bg-opacity-30 p-3 rounded-lg">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                            </svg>
                        </div>
                    </div>
                </div>


                <div className="stat-card bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-indigo-100 text-sm font-medium">Payment Status</p>
                            <div className="mt-2">
                                <p className="text-xs text-indigo-100">Total: ₹{summary?.total_sale_payment?.toFixed(2) || '0.00'}</p>
                                <p className="text-2xl font-bold">Paid: ₹{summary?.received_payment?.toFixed(2) || '0.00'}</p>
                            </div>
                        </div>
                        <div className="bg-indigo-400 bg-opacity-30 p-3 rounded-lg">
                            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>

            {/* Daily Product Sales */}
            <div className="card p-6 mb-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Today's Product Wise Sales</h2>
                {productSales.length === 0 ? (
                    <p className="text-gray-500 text-center py-4">No sales today</p>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="border-b border-gray-200">
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Product</th>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">SKU</th>
                                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Qty Sold</th>
                                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Total Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {productSales.map((item, index) => (
                                    <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                                        <td className="py-3 px-4 text-sm font-medium text-gray-900">{item.product_name}</td>
                                        <td className="py-3 px-4 text-sm text-gray-600">{item.sku}</td>
                                        <td className="py-3 px-4 text-sm font-medium text-center text-gray-900">{item.total_qty}</td>
                                        <td className="py-3 px-4 text-sm font-medium text-right text-gray-900">₹{parseFloat(item.total_amount).toFixed(2)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* Recent Orders */}
            <div className="card p-6">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-semibold text-gray-900">Recent Orders</h2>
                    <Link to="/orders" className="text-primary-600 hover:text-primary-700 font-medium">
                        View All →
                    </Link>
                </div>

                {recentOrders.length === 0 ? (
                    <p className="text-gray-500 text-center py-8">No orders yet</p>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full">
                            <thead>
                                <tr className="border-b border-gray-200">
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Order ID</th>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Customer</th>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Items</th>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Amount</th>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {recentOrders.map((order) => (
                                    <tr key={order.id} className="border-b border-gray-100 hover:bg-gray-50">
                                        <td className="py-3 px-4 text-sm font-medium text-gray-900">{order.bill_no}</td>
                                        <td className="py-3 px-4 text-sm text-gray-600">{order.buyer_name || order.customer_name}</td>
                                        <td className="py-3 px-4 text-sm text-gray-600">{order.item_count}</td>
                                        <td className="py-3 px-4 text-sm font-medium text-gray-900">₹{parseFloat(order.net_amount).toFixed(2)}</td>
                                        <td className="py-3 px-4">
                                            <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${order.order_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                                order.order_status === 'confirmed' ? 'bg-blue-100 text-blue-800' :
                                                    order.order_status === 'processing' ? 'bg-purple-100 text-purple-800' :
                                                        order.order_status === 'shipped' ? 'bg-indigo-100 text-indigo-800' :
                                                            order.order_status === 'delivered' ? 'bg-green-100 text-green-800' :
                                                                'bg-red-100 text-red-800'
                                                }`}>
                                                {order.order_status}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div >
    );
};

export default Dashboard;
