import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../utils/api';

const CreateOrder = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [products, setProducts] = useState([]);
    const [user] = useState(JSON.parse(localStorage.getItem('admin_user') || '{}'));
    const [customerDetails, setCustomerDetails] = useState({
        name: '',
        phone: '',
        address: '',
        email: ''
    });
    const [deliveryAddress, setDeliveryAddress] = useState('');
    const [orderNotes, setOrderNotes] = useState('');
    const [orderItems, setOrderItems] = useState([]);
    const [selectedProduct, setSelectedProduct] = useState('');
    const [quantity, setQuantity] = useState(1);
    const [itemDiscount, setItemDiscount] = useState(0);
    const [error, setError] = useState('');

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            const response = await api.get('/products/read.php?limit=5000');
            setProducts(response.data.products || []);
        } catch (error) {
            console.error('Failed to fetch products:', error);
        }
    };

    const addProductToOrder = () => {
        if (!selectedProduct) {
            setError('Please select a product');
            return;
        }

        const product = products.find(p => p.id == selectedProduct);
        if (!product) return;

        const cashDiscPercent = parseFloat(itemDiscount) || 0;
        const originalRate = parseFloat(product.price);

        // Calculate Company Discount
        let companyDiscountValue = 0;
        const companyDiscRaw = product.discount || '0';
        if (companyDiscRaw.toString().includes('%')) {
            const pct = parseFloat(companyDiscRaw.replace('%', ''));
            companyDiscountValue = (originalRate * pct) / 100;
        } else {
            companyDiscountValue = parseFloat(companyDiscRaw);
        }

        // Calculate Cash Discount Value
        const cashDiscountValue = (originalRate * cashDiscPercent) / 100;

        // Final Rate
        let finalRate = originalRate - companyDiscountValue - cashDiscountValue;
        if (finalRate < 0) finalRate = 0;

        const newLineItem = {
            temp_id: Date.now(),
            product_id: product.id,
            product_name: product.name,
            qty: quantity,

            // Storing all value metrics
            original_rate: originalRate,
            company_discount: companyDiscountValue,
            cash_discount_percentage: cashDiscPercent,
            cash_discount_value: cashDiscountValue,

            rate: finalRate, // Explicitly the final rate
            discount: (companyDiscountValue + cashDiscountValue) * quantity // For backward compat total tracking
        };

        setOrderItems([...orderItems, newLineItem]);

        setSelectedProduct('');
        setQuantity(1);
        setItemDiscount(0);
        setError('');
    };

    const removeProduct = (tempId) => {
        setOrderItems(orderItems.filter(item => item.temp_id !== tempId));
    };

    const calculateTotals = () => {
        const grossAmount = orderItems.reduce((sum, item) => sum + (item.qty * item.rate), 0);
        return { grossAmount };
    };

    const [discount, setDiscount] = useState(0);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (!customerDetails.name || !customerDetails.phone || !customerDetails.address) {
            setError('Please fill in all customer details');
            return;
        }

        if (orderItems.length === 0) {
            setError('Please add at least one product to the order');
            return;
        }

        setLoading(true);

        try {
            const orderData = {
                customer_name: customerDetails.name,
                customer_phone: customerDetails.phone,
                customer_address: customerDetails.address,
                customer_email: customerDetails.email,
                delivery_address: deliveryAddress || customerDetails.address,
                order_notes: orderNotes,
                items: orderItems.map(item => ({
                    product_id: item.product_id,
                    qty: item.qty,
                    cash_discount_percentage: item.cash_discount_percentage,
                    discount: item.discount || 0 // Legacy total discount field
                })),
                discount: discount,
                admin_created: true
            };

            const response = await api.post('/orders/create-admin.php', orderData);
            alert('Order created successfully! Invoice URL: ' + response.data.order.invoice_url);
            navigate('/admin/orders');
        } catch (error) {
            setError(error.response?.data?.error || 'Failed to create order');
        } finally {
            setLoading(false);
        }
    };

    const { grossAmount } = calculateTotals();

    return (
        <div className="p-6">
            <div className="mb-6">
                <h1 className="text-3xl font-bold text-gray-900">Create Order</h1>
                <p className="text-gray-600 mt-1">Create a new order for a client</p>
            </div>

            {error && (
                <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                    {error}
                </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Order Taken By */}
                <div className="lg:col-span-3">
                    <div className="card p-4 flex items-center gap-4 bg-primary-50 border border-primary-100">
                        <span className="font-semibold text-primary-900">Order Taken By:</span>
                        <span className="text-lg font-bold text-primary-700">{user.firstname} {user.lastname}</span>
                    </div>
                </div>

                {/* Customer Details */}
                <div className="lg:col-span-2">
                    <div className="card p-6 mb-6">
                        <h2 className="text-xl font-semibold mb-4">Customer Details</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Name *
                                </label>
                                <input
                                    type="text"
                                    value={customerDetails.name}
                                    onChange={(e) => setCustomerDetails({ ...customerDetails, name: e.target.value })}
                                    className="input-field"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Phone *
                                </label>
                                <input
                                    type="tel"
                                    value={customerDetails.phone}
                                    onChange={(e) => setCustomerDetails({ ...customerDetails, phone: e.target.value })}
                                    className="input-field"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Email
                                </label>
                                <input
                                    type="email"
                                    value={customerDetails.email}
                                    onChange={(e) => setCustomerDetails({ ...customerDetails, email: e.target.value })}
                                    className="input-field"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Address *
                                </label>
                                <input
                                    type="text"
                                    value={customerDetails.address}
                                    onChange={(e) => setCustomerDetails({ ...customerDetails, address: e.target.value })}
                                    className="input-field"
                                    required
                                />
                            </div>
                            <div className="md:col-span-2">
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Delivery Address (if different)
                                </label>
                                <input
                                    type="text"
                                    value={deliveryAddress}
                                    onChange={(e) => setDeliveryAddress(e.target.value)}
                                    className="input-field"
                                    placeholder="Leave empty to use customer address"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Add Products */}
                    <div className="card p-6 mb-6">
                        <h2 className="text-xl font-semibold mb-4">Add Products</h2>
                        <div className="flex gap-2 mb-4">
                            <select
                                value={selectedProduct}
                                onChange={(e) => setSelectedProduct(e.target.value)}
                                className="flex-1 input-field"
                            >
                                <option value="">Select Product...</option>
                                {products.map(product => (
                                    <option key={product.id} value={product.id}>
                                        {product.name} {product.sku ? `(${product.sku})` : ''} - ₹{parseFloat(product.price).toFixed(2)}
                                    </option>
                                ))}
                            </select>
                            <input
                                type="number"
                                min="1"
                                value={quantity}
                                onChange={(e) => setQuantity(parseInt(e.target.value))}
                                className="w-24 input-field"
                                placeholder="Qty"
                            />
                            <input
                                type="number"
                                min="0"
                                value={itemDiscount}
                                onChange={(e) => setItemDiscount(parseFloat(e.target.value))}
                                className="w-32 input-field"
                                placeholder="Cash Disc (%)"
                            />
                            <button
                                type="button"
                                onClick={addProductToOrder}
                                className="btn-primary"
                            >
                                Add
                            </button>
                        </div>

                        {/* Selected Product Preview */}
                        {selectedProduct && (
                            <div className="mb-4 bg-gray-50 p-3 rounded border border-gray-200 text-sm flex gap-6">
                                <div>
                                    <span className="font-semibold text-gray-700">Original Price:</span>
                                    <span className="ml-2 text-gray-900">₹{parseFloat(products.find(p => p.id == selectedProduct)?.price || 0).toFixed(2)}</span>
                                </div>
                                <div>
                                    <span className="font-semibold text-gray-700">Company Discount:</span>
                                    <span className="ml-2 text-gray-900">{products.find(p => p.id == selectedProduct)?.discount || '0'}</span>
                                </div>
                            </div>
                        )}

                        {/* Order Items */}
                        {orderItems.length > 0 && (
                            <div className="mt-4">
                                <h3 className="text-lg font-medium text-gray-900 mb-2">Order Items</h3>
                                <div className="overflow-x-auto">
                                    <table className="w-full border border-gray-200 rounded">
                                        <thead className="bg-gray-50">
                                            <tr>
                                                <th className="text-left py-2 px-3 text-sm font-semibold text-gray-700">Product</th>
                                                <th className="text-center py-2 px-3 text-sm font-semibold text-gray-700">Qty</th>
                                                <th className="text-right py-2 px-3 text-sm font-semibold text-gray-700">Orig. Rate</th>
                                                <th className="text-right py-2 px-3 text-sm font-semibold text-gray-700">Co. Disc</th>
                                                <th className="text-right py-2 px-3 text-sm font-semibold text-gray-700">Cash Disc (%)</th>
                                                <th className="text-right py-2 px-3 text-sm font-semibold text-gray-700">Final Rate</th>
                                                <th className="text-right py-2 px-3 text-sm font-semibold text-gray-700">Amount</th>
                                                <th className="text-center py-2 px-3 text-sm font-semibold text-gray-700">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-200">
                                            {orderItems.map((item) => (
                                                <tr key={item.temp_id}>
                                                    <td className="py-2 px-3 text-sm">{item.product_name}</td>
                                                    <td className="py-2 px-3 text-sm text-center">{item.qty}</td>
                                                    <td className="py-2 px-3 text-sm text-right">₹{item.original_rate.toFixed(2)}</td>
                                                    <td className="py-2 px-3 text-sm text-right">₹{item.company_discount.toFixed(2)}</td>
                                                    <td className="py-2 px-3 text-sm text-right">{item.cash_discount_percentage}%</td>
                                                    <td className="py-2 px-3 text-sm text-right">₹{item.rate.toFixed(2)}</td>
                                                    <td className="py-2 px-3 text-sm text-right">₹{(item.qty * item.rate).toFixed(2)}</td>
                                                    <td className="py-2 px-3 text-center">
                                                        <button
                                                            type="button"
                                                            onClick={() => removeProduct(item.temp_id)}
                                                            className="text-red-600 hover:text-red-800 text-sm"
                                                        >
                                                            Remove
                                                        </button>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}


                    </div>

                    {/* Order Notes */}
                    <div className="card p-6">
                        <h2 className="text-xl font-semibold mb-4">Order Notes</h2>
                        <textarea
                            value={orderNotes}
                            onChange={(e) => setOrderNotes(e.target.value)}
                            className="input-field"
                            rows="3"
                            placeholder="Any special instructions..."
                        />
                    </div>
                </div>

                {/* Order Summary */}
                <div className="lg:col-span-1">
                    <div className="card p-6 sticky top-6">
                        <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
                        <div className="space-y-2 mb-4">
                            <div className="flex justify-between">
                                <span>Items:</span>
                                <span>{orderItems.length}</span>
                            </div>
                            <div className="flex justify-between">
                                <span>Total Quantity:</span>
                                <span>{orderItems.reduce((sum, item) => sum + item.qty, 0)}</span>
                            </div>
                            <div className="flex justify-between font-bold text-lg border-t pt-2">
                                <span>Gross Amount:</span>
                                <span>₹{grossAmount.toFixed(2)}</span>
                            </div>
                        </div>
                        <button
                            onClick={handleSubmit}
                            disabled={loading || orderItems.length === 0}
                            className="w-full btn-primary disabled:opacity-50"
                        >
                            {loading ? 'Creating...' : 'Create Order'}
                        </button>
                        <button
                            onClick={() => navigate('/admin/orders')}
                            className="w-full btn-secondary mt-2"
                        >
                            Cancel
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CreateOrder;
