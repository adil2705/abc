import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../utils/api';

const ManageProducts = () => {
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [page, setPage] = useState(1);
    const [pagination, setPagination] = useState(null);

    useEffect(() => {
        fetchProducts();
    }, [page, search]);

    const fetchProducts = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams({
                page: page.toString(),
                limit: '20'
            });
            if (search) params.append('search', search);

            const response = await api.get(`/products/read.php?${params}`);
            setProducts(response.data.products);
            setPagination(response.data.pagination);
        } catch (error) {
            console.error('Failed to fetch products:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id) => {
        if (!confirm('Are you sure you want to delete this product?')) return;

        try {
            await api.delete('/products/delete.php', { data: { id } });
            fetchProducts();
        } catch (error) {
            alert(error.response?.data?.error || 'Failed to delete product');
        }
    };

    const handleSearch = (e) => {
        e.preventDefault();
        setPage(1);
        fetchProducts();
    };

    if (loading && products.length === 0) {
        return (
            <div className="flex items-center justify-center h-screen">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            </div>
        );
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Manage Products</h1>
                    <p className="text-gray-600 mt-1">View and manage all products</p>
                </div>
                <Link to="/admin/products/add" className="btn-primary">
                    + Add Product
                </Link>
            </div>

            <div className="card p-6">
                <form onSubmit={handleSearch} className="mb-4">
                    <div className="flex gap-2">
                        <input
                            type="text"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            placeholder="Search by name or SKU..."
                            className="flex-1 input-field"
                        />
                        <button type="submit" className="btn-primary">
                            Search
                        </button>
                        {search && (
                            <button
                                type="button"
                                onClick={() => {
                                    setSearch('');
                                    setPage(1);
                                }}
                                className="btn-secondary"
                            >
                                Clear
                            </button>
                        )}
                    </div>
                </form>

                {products.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No products found</p>
                ) : (
                    <>
                        <div className="overflow-x-auto">
                            <table className="w-full">
                                <thead>
                                    <tr className="border-b border-gray-200">
                                        <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Image</th>
                                        <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">SKU</th>
                                        <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Name</th>
                                        <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Brand</th>
                                        <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Category</th>
                                        <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Price</th>
                                        <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Discount</th>
                                        <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Status</th>
                                        <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {products.map((product) => (
                                        <tr key={product.id} className="border-b border-gray-100 hover:bg-gray-50">
                                            <td className="py-3 px-4">
                                                {product.image ? (
                                                    <img
                                                        src={`http://localhost/sans_traders-master${product.image}`}
                                                        alt={product.name}
                                                        className="w-12 h-12 object-cover rounded border border-gray-200"
                                                        onError={(e) => {
                                                            e.target.onerror = null;
                                                            e.target.src = 'https://placehold.co/100x100?text=No+Image';
                                                        }}
                                                    />
                                                ) : (
                                                    <div className="w-12 h-12 bg-gray-100 rounded border border-gray-200 flex items-center justify-center">
                                                        <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                                        </svg>
                                                    </div>
                                                )}
                                            </td>
                                            <td className="py-3 px-4 text-sm font-medium text-gray-900">{product.sku}</td>
                                            <td className="py-3 px-4 text-sm text-gray-900">{product.name}</td>
                                            <td className="py-3 px-4 text-sm text-gray-600">{product.brand_name}</td>
                                            <td className="py-3 px-4 text-sm text-gray-600">{product.category_name}</td>
                                            <td className="py-3 px-4 text-sm font-medium text-right text-gray-900">
                                                ₹{parseFloat(product.price).toFixed(2)}
                                            </td>
                                            <td className="py-3 px-4 text-sm text-right text-gray-600">{product.discount || '0%'}</td>
                                            <td className="py-3 px-4 text-center">
                                                <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${product.availability == 1
                                                    ? 'bg-green-100 text-green-800'
                                                    : 'bg-red-100 text-red-800'
                                                    }`}>
                                                    {product.availability == 1 ? 'Active' : 'Inactive'}
                                                </span>
                                            </td>
                                            <td className="py-3 px-4 text-center">
                                                <div className="flex items-center justify-center gap-2">
                                                    <Link
                                                        to={`/admin/products/edit/${product.id}`}
                                                        className="text-blue-600 hover:text-blue-800 font-medium text-sm"
                                                    >
                                                        Edit
                                                    </Link>
                                                    <button
                                                        onClick={() => handleDelete(product.id)}
                                                        className="text-red-600 hover:text-red-800 font-medium text-sm"
                                                    >
                                                        Delete
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        {pagination && pagination.pages > 1 && (
                            <div className="flex justify-center items-center space-x-2 mt-4">
                                <button
                                    onClick={() => setPage(page - 1)}
                                    disabled={page === 1}
                                    className="btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    Previous
                                </button>
                                <span className="text-gray-600">
                                    Page {page} of {pagination.pages}
                                </span>
                                <button
                                    onClick={() => setPage(page + 1)}
                                    disabled={page === pagination.pages}
                                    className="btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    Next
                                </button>
                            </div>
                        )}
                    </>
                )}
            </div>
        </div>
    );
};

export default ManageProducts;
