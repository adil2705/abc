import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from '../../utils/api';

const EditUser = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        group_id: '',
        username: '',
        email: '',
        password: '',
        confirm_password: '',
        firstname: '',
        lastname: '',
        phone: '',
        gender: 1
    });
    const [groups, setGroups] = useState([]);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Fetch groups
        // Using same hardcoded groups as AddUser for now or from API if available
        setGroups([
            { id: 1, name: 'Administrator' },
            { id: 4, name: 'Owners' },
            { id: 5, name: 'Employee' }
        ]);

        fetchUser();
    }, [id]);

    const fetchUser = async () => {
        try {
            // Need a detail endpoint or fetch from list.
            // Assuming /users/read.php implies list, maybe we can filter client side or need a detail endpoint.
            // Let's assume we can GET /users/read.php?id=ID or similar, OR just filter from all users if dataset is small.
            // Looking at backend/api/users/read.php (not viewed yet), usually it returns all. 
            // Let's try fetching all and finding one, or if there's a specific endpoint. 
            // In the file list, I saw "users/read.php".

            // Optimization: Create a proper fetch single user if not exists.
            // For now, let's try to fetch all and filter.
            const response = await axios.get('/users/read.php');
            const user = response.data.find(u => u.id == id);

            if (user) {
                // Map user data to form
                setFormData({
                    id: user.id,
                    group_id: user.groups && user.groups.length > 0 ? user.groups[0].group_id : '',
                    username: user.username,
                    email: user.email,
                    password: '', // Don't prefill password
                    confirm_password: '',
                    firstname: user.firstname,
                    lastname: user.lastname,
                    phone: user.phone,
                    gender: user.gender
                });
            } else {
                setError('User not found');
            }
        } catch (err) {
            setError('Failed to fetch user details');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (formData.password && formData.password !== formData.confirm_password) {
            setError("Passwords do not match");
            return;
        }

        try {
            // Prepare data - only send password if changed
            const dataToSend = { ...formData };
            if (!dataToSend.password) {
                delete dataToSend.password;
                delete dataToSend.confirm_password;
            }

            // Format groups: backend expects 'groups' array
            // If the selector handles single group_id:
            if (dataToSend.group_id) {
                dataToSend.groups = [dataToSend.group_id];
            }

            await axios.post('/users/update.php', dataToSend);
            navigate('/admin/users/manage');
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to update user');
        }
    };

    if (loading) return <div className="p-6">Loading...</div>;

    return (
        <div className="bg-white p-6 rounded shadow-md m-4">
            <h2 className="text-xl font-semibold mb-4 border-b pb-2">Edit User</h2>
            {error && <div className="text-red-500 mb-4">{error}</div>}

            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-gray-700 font-bold mb-2">Groups</label>
                    <select
                        name="group_id"
                        value={formData.group_id}
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select Groups</option>
                        {groups.map(g => (
                            <option key={g.id} value={g.id}>{g.name}</option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Username</label>
                    <input
                        type="text"
                        name="username"
                        value={formData.username}
                        placeholder="Username"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Email</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        placeholder="Email"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Password (Leave blank to keep current)</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        placeholder="New Password"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Confirm password</label>
                    <input
                        type="password"
                        name="confirm_password"
                        value={formData.confirm_password}
                        placeholder="Confirm New Password"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">First name</label>
                    <input
                        type="text"
                        name="firstname"
                        value={formData.firstname}
                        placeholder="First name"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Last name</label>
                    <input
                        type="text"
                        name="lastname"
                        value={formData.lastname}
                        placeholder="Last name"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Phone</label>
                    <input
                        type="text"
                        name="phone"
                        value={formData.phone}
                        placeholder="Phone"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Gender</label>
                    <div className="flex gap-4">
                        <label className="flex items-center">
                            <input
                                type="radio"
                                name="gender"
                                value="1"
                                checked={formData.gender == 1}
                                onChange={handleChange}
                                className="mr-2"
                            /> Male
                        </label>
                        <label className="flex items-center">
                            <input
                                type="radio"
                                name="gender"
                                value="2"
                                checked={formData.gender == 2}
                                onChange={handleChange}
                                className="mr-2"
                            /> Female
                        </label>
                    </div>
                </div>

                <div className="flex gap-2 mt-6">
                    <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Update User</button>
                    <button type="button" onClick={() => navigate('/admin/users/manage')} className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">Back</button>
                </div>
            </form>
        </div>
    );
};

export default EditUser;
