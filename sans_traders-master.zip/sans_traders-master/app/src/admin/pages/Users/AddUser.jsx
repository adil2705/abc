import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../../utils/api'; // Assuming a configured axios instance

const AddUser = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        group_id: '',
        username: '',
        email: '',
        password: '',
        confirm_password: '',
        firstname: '',
        lastname: '',
        phone: '',
        gender: 1 // Default Male
    });
    const [groups, setGroups] = useState([]); // Fetch from API if needed, or hardcode for now
    const [error, setError] = useState('');

    useEffect(() => {
        // Fetch groups if an API exists, or verify hardcoded content
        // For now assuming we might need to fetch groups
        // axios.get('/groups/read.php').then(res => setGroups(res.data)).catch(...)
        // Mocking groups based on SQL: 1=Admin, 4=Owners, 5=Employee
        setGroups([
            { id: 1, name: 'Administrator' },
            { id: 4, name: 'Owners' },
            { id: 5, name: 'Employee' }
        ]);
    }, []);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (formData.password !== formData.confirm_password) {
            setError("Passwords do not match");
            return;
        }

        try {
            await axios.post('/users/create.php', formData);
            navigate('/admin/users/manage');
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to create user');
        }
    };

    return (
        <div className="bg-white p-6 rounded shadow-md m-4">
            <h2 className="text-xl font-semibold mb-4 border-b pb-2">Add User</h2>
            {error && <div className="text-red-500 mb-4">{error}</div>}

            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label className="block text-gray-700 font-bold mb-2">Groups</label>
                    <select
                        name="group_id"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select Groups</option>
                        {groups.map(g => (
                            <option key={g.id} value={g.id}>{g.name}</option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Username</label>
                    <input
                        type="text"
                        name="username"
                        placeholder="Username"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Email</label>
                    <input
                        type="email"
                        name="email"
                        placeholder="Email"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Password</label>
                    <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Confirm password</label>
                    <input
                        type="password"
                        name="confirm_password"
                        placeholder="Confirm Password"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">First name</label>
                    <input
                        type="text"
                        name="firstname"
                        placeholder="First name"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Last name</label>
                    <input
                        type="text"
                        name="lastname"
                        placeholder="Last name"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                    />
                </div>

                <div>
                    <label className="block text-gray-700 font-bold mb-2">Phone</label>
                    <input
                        type="text"
                        name="phone"
                        placeholder="Phone"
                        className="w-full border rounded p-2"
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="md:col-span-2">
                    <label className="block text-gray-700 font-bold mb-2">Gender</label>
                    <div className="flex gap-4">
                        <label className="flex items-center">
                            <input
                                type="radio"
                                name="gender"
                                value="1"
                                checked={formData.gender == 1}
                                onChange={handleChange}
                                className="mr-2"
                            /> Male
                        </label>
                        <label className="flex items-center">
                            <input
                                type="radio"
                                name="gender"
                                value="2"
                                checked={formData.gender == 2}
                                onChange={handleChange}
                                className="mr-2"
                            /> Female
                        </label>
                    </div>
                </div>

                <div className="flex gap-2 mt-6 md:col-span-2">
                    <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Save Changes</button>
                    <button type="button" onClick={() => navigate('/admin/users/manage')} className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">Back</button>
                </div>
            </form>
        </div>
    );
};

export default AddUser;
