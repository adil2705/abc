import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from '../../utils/api';
// Using mock icons or simpler ones if lucide-react not available, but assuming available or using text/html
// If needed, can import from 'lucide-react' e.g. Trash2, Edit.

const ManageUsers = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchUsers();
    }, []);

    const fetchUsers = async () => {
        try {
            const response = await axios.get('/users/read.php');
            setUsers(response.data);
        } catch (error) {
            console.error('Error fetching users:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this user?')) {
            try {
                await axios.post('/users/delete.php', { id });
                fetchUsers();
            } catch (error) {
                alert('Failed to delete user');
            }
        }
    };

    if (loading) return <div className="p-4">Loading...</div>;

    return (
        <div className="m-4">
            <div className="bg-white p-4 rounded shadow-md mb-4 flex justify-between items-center">
                <h2 className="text-xl font-semibold">Manage Users</h2>
                <Link to="/admin/users/add" className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Add User</Link>
            </div>

            <div className="bg-white p-4 rounded shadow-md overflow-x-auto">
                <div className="flex justify-between mb-4">
                    <div className="flex items-center gap-2">
                        Show <select className="border rounded p-1"><option>10</option></select> entries
                    </div>
                    <div className="flex items-center gap-2">
                        Search: <input type="text" className="border rounded p-1" />
                    </div>
                </div>

                <table className="w-full text-left border-collapse">
                    <thead>
                        <tr className="border-b">
                            <th className="p-2">Username</th>
                            <th className="p-2">Email</th>
                            <th className="p-2">Name</th>
                            <th className="p-2">Phone</th>
                            <th className="p-2">Group</th>
                            <th className="p-2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.id} className="border-b hover:bg-gray-50">
                                <td className="p-2">{user.username}</td>
                                <td className="p-2">{user.email}</td>
                                <td className="p-2">{user.firstname} {user.lastname}</td>
                                <td className="p-2">{user.phone}</td>
                                <td className="p-2">
                                    {user.groups && user.groups.map(g => g.group_name).join(', ')}
                                </td>
                                <td className="p-2 flex gap-2">
                                    {/* Assuming Edit functionality uses AddUser with params or separate EditUser page. 
                        For now just linking to add potentially or creating EditUser.
                        Let's focus on listing as requested first, edit can come later/optional. 
                    */}
                                    <Link to={`/admin/users/edit/${user.id}`} className="p-1 border rounded bg-gray-100 hover:bg-blue-100 block"><span role="img" aria-label="edit">✏️</span></Link>
                                    <button onClick={() => handleDelete(user.id)} className="p-1 border rounded bg-gray-100 hover:bg-red-100"><span role="img" aria-label="delete">🗑️</span></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <div className="mt-4 flex justify-between text-sm text-gray-600">
                    <div>Showing 1 to {users.length} of {users.length} entries</div>
                    <div className="flex gap-1">
                        <button className="px-2 py-1 border rounded disabled:opacity-50" disabled>Previous</button>
                        <button className="px-2 py-1 border rounded bg-blue-500 text-white">1</button>
                        <button className="px-2 py-1 border rounded disabled:opacity-50" disabled>Next</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ManageUsers;
