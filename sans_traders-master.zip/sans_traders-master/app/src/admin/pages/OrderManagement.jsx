import React, { useState, useEffect } from 'react';
import api from '../utils/api';
import OrderDetailsModal from '../components/OrderDetailsModal';

const OrderManagement = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState('');
    const [selectedOrder, setSelectedOrder] = useState(null);
    const [viewOrder, setViewOrder] = useState(null);
    const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, pages: 0 });

    useEffect(() => {
        fetchOrders();
    }, [statusFilter, pagination.page, pagination.limit]);

    const fetchOrders = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (statusFilter) params.append('status', statusFilter);
            if (searchTerm) params.append('search', searchTerm);
            params.append('page', pagination.page);
            params.append('limit', pagination.limit);

            const response = await api.get(`/admin/orders.php?${params}`);
            setOrders(response.data.orders);
            setPagination(prev => ({ ...prev, ...response.data.pagination }));
        } catch (error) {
            console.error('Failed to fetch orders:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = () => {
        setPagination(prev => ({ ...prev, page: 1 }));
        fetchOrders();
    };

    const getStatusColor = (status) => {
        const colors = {
            pending: 'bg-yellow-100 text-yellow-800',
            confirmed: 'bg-blue-100 text-blue-800',
            processing: 'bg-purple-100 text-purple-800',
            shipped: 'bg-indigo-100 text-indigo-800',
            delivered: 'bg-green-100 text-green-800',
            cancelled: 'bg-red-100 text-red-800',
        };
        return colors[status] || 'bg-gray-100 text-gray-800';
    };

    const handlePaymentStatusUpdate = async (id, currentStatus) => {
        try {
            const newStatus = currentStatus == 1 ? 0 : 1;
            await api.put('/admin/orders.php', { order_id: id, paid_status: newStatus });
            fetchOrders();
        } catch (error) {
            console.error('Failed to update payment status:', error);
            alert('Failed to update payment status');
        }
    };

    const handleStatusUpdate = async (id, status) => {
        try {
            await api.put('/admin/orders.php', { order_id: id, status });
            // Refresh orders
            fetchOrders();
            // Show success notification (optional if you want to add toast later)
        } catch (error) {
            console.error('Failed to update status:', error);
            alert('Failed to update status');
        }
    };

    // ... (keep getStatusColor)

    const handleDownloadInvoice = (orderId) => {
        // Assuming the backend is running on the same host/port structure or using the API URL
        // We'll need to construct the URL correctly.
        // For now, let's assume relative path works if proxied, or we need the base ID.
        // Since we don't have the base URL handy in a variable, we can try to guess or hardcode based on env.
        // Better approach: Use the Axios instance's default baseURL or a known env var.
        const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://localhost/sans_traders-master/backend/api';
        window.open(`${baseURL}/orders/invoice.php?id=${orderId}`, '_blank');
    };

    return (
        <div className="p-6">
            <h1 className="text-3xl font-bold text-gray-900 mb-6">Order Management</h1>

            {/* Filters */}
            <div className="card p-4 mb-6">
                <div className="flex flex-col md:flex-row gap-4 items-end md:items-center">
                    <div className="flex-1 w-full">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Search</label>
                        <input
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Order ID, Customer Name..."
                            className="input-field w-full"
                        />
                    </div>
                    <div className="w-full md:w-48">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                        <select
                            value={statusFilter}
                            onChange={(e) => {
                                setStatusFilter(e.target.value);
                                setPagination(prev => ({ ...prev, page: 1 }));
                            }}
                            className="input-field w-full"
                        >
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="processing">Processing</option>
                            <option value="shipped">Shipped</option>
                            <option value="delivered">Delivered</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <button onClick={handleSearch} className="btn-primary w-full md:w-auto h-10 mb-[2px]">
                        Search
                    </button>
                </div>
            </div>

            {/* Orders Table/List */}
            {loading ? (
                <div className="flex justify-center items-center h-64">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
                </div>
            ) : orders.length === 0 ? (
                <div className="card p-12 text-center">
                    <p className="text-gray-500 text-lg">No orders found</p>
                </div>
            ) : (
                <>
                    {/* Desktop Table */}
                    <div className="hidden md:block overflow-x-auto card">
                        <table className="w-full">
                            <thead className="bg-gray-50 border-b border-gray-200">
                                <tr>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Order ID</th>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Date</th>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Customer</th>
                                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Amount</th>
                                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Payment</th>
                                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-700">Status</th>
                                    <th className="text-right py-3 px-4 text-sm font-semibold text-gray-700">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {orders.map((order) => (
                                    <React.Fragment key={order.id}>
                                        <tr className="hover:bg-gray-50">
                                            <td className="py-3 px-4 text-sm font-medium text-gray-900">#{order.bill_no}</td>
                                            <td className="py-3 px-4 text-sm text-gray-600">
                                                {new Date(order.date_time * 1000).toLocaleDateString()}
                                            </td>
                                            <td className="py-3 px-4 text-sm text-gray-600">
                                                {order.buyer_name || order.customer_name}
                                                <div className="text-xs text-gray-400">{order.buyer_email || order.customer_phone}</div>
                                            </td>
                                            <td className="py-3 px-4 text-sm font-medium text-gray-900">
                                                ₹{parseFloat(order.net_amount).toFixed(2)}
                                            </td>
                                            <td className="py-3 px-4 text-center">
                                                <button
                                                    onClick={() => handlePaymentStatusUpdate(order.id, order.paid_status)}
                                                    className={`px-3 py-1 rounded-full text-xs font-semibold ${order.paid_status == 1
                                                        ? 'bg-green-100 text-green-800 border border-green-200'
                                                        : 'bg-red-100 text-red-800 border border-red-200'
                                                        }`}
                                                >
                                                    {order.paid_status == 1 ? 'Mark as Unpaid' : 'Mark as Paid'}
                                                </button>
                                            </td>
                                            <td className="py-3 px-4 text-center">
                                                <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(order.order_status)}`}>
                                                    {order.order_status}
                                                </span>
                                            </td>
                                            <td className="py-3 px-4 text-right space-x-2">
                                                <button
                                                    onClick={() => setViewOrder(order)}
                                                    className="text-primary-600 hover:text-primary-800 text-sm font-medium"
                                                >
                                                    Details
                                                </button>
                                                <button
                                                    onClick={() => handleDownloadInvoice(order.id)}
                                                    className="text-gray-600 hover:text-gray-800 text-sm"
                                                    title="Download Invoice"
                                                >
                                                    📄
                                                </button>
                                            </td>
                                        </tr>
                                        {selectedOrder?.id === order.id && (
                                            <tr>
                                                <td colSpan="6" className="bg-gray-50 p-4">
                                                    {/* Expanded Update & Details View */}
                                                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                                        <div>
                                                            <h4 className="font-medium text-gray-900 mb-3">Update Status</h4>
                                                            <div className="grid grid-cols-3 gap-2">
                                                                {['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'].map((status) => (
                                                                    <button
                                                                        key={status}
                                                                        onClick={() => handleStatusUpdate(order.id, status)}
                                                                        className={`py-2 px-2 text-sm rounded border transition-colors ${order.order_status === status
                                                                            ? 'bg-primary-600 text-white border-primary-600'
                                                                            : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                                                                            }`}
                                                                    >
                                                                        {status.charAt(0).toUpperCase() + status.slice(1)}
                                                                    </button>
                                                                ))}
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <h4 className="font-medium text-gray-900 mb-3">Order Items</h4>
                                                            <div className="space-y-2 max-h-40 overflow-y-auto">
                                                                {order.items.map((item) => (
                                                                    <div key={item.id} className="flex justify-between text-sm bg-white p-2 rounded border border-gray-200">
                                                                        <span>{item.product_name} x {item.qty}</span>
                                                                        <span>₹{parseFloat(item.amount).toFixed(2)}</span>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        )}
                                    </React.Fragment>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    {/* Mobile Card View (Hidden on Desktop) */}
                    <div className="md:hidden space-y-4">
                        {orders.map((order) => (
                            <div key={order.id} className="card p-4">
                                <div className="flex justify-between items-start mb-3">
                                    <div>
                                        <h3 className="font-semibold text-gray-900">#{order.bill_no}</h3>
                                        <p className="text-xs text-gray-500">{new Date(order.date_time * 1000).toLocaleDateString()}</p>
                                    </div>
                                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(order.order_status)}`}>
                                        {order.order_status}
                                    </span>
                                </div>
                                <div className="mb-3">
                                    <p className="text-sm text-gray-800 font-medium">{order.buyer_name || order.customer_name}</p>
                                    <div className="flex justify-between items-center mt-1">
                                        <p className="text-sm text-gray-600">Total: ₹{parseFloat(order.net_amount).toFixed(2)}</p>
                                        <button
                                            onClick={() => handlePaymentStatusUpdate(order.id, order.paid_status)}
                                            className={`px-2 py-0.5 rounded text-xs font-medium ${order.paid_status == 1
                                                ? 'bg-green-100 text-green-800'
                                                : 'bg-red-100 text-red-800'
                                                }`}
                                        >
                                            {order.paid_status == 1 ? 'Mark as Unpaid' : 'Mark as Paid'}
                                        </button>
                                    </div>
                                </div>
                                <div className="flex justify-between items-center border-t pt-3">
                                    <button
                                        onClick={() => handleDownloadInvoice(order.id)}
                                        className="text-gray-600 text-sm flex items-center gap-1"
                                    >
                                        <span>📄 Invoice</span>
                                    </button>
                                    <button
                                        onClick={() => setViewOrder(order)}
                                        className="btn-secondary text-sm py-1 px-3"
                                    >
                                        Details
                                    </button>
                                </div>
                                {selectedOrder?.id === order.id && (
                                    <div className="mt-4 pt-4 border-t">
                                        <h4 className="font-medium text-sm mb-2">Update Status</h4>
                                        <div className="grid grid-cols-2 gap-2">
                                            {['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'].map((status) => (
                                                <button
                                                    key={status}
                                                    onClick={() => handleStatusUpdate(order.id, status)}
                                                    className={`py-1 px-2 text-xs rounded border ${order.order_status === status
                                                        ? 'bg-primary-600 text-white'
                                                        : 'bg-white text-gray-700'
                                                        }`}
                                                >
                                                    {status}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>

                    {/* Pagination Controls */}
                    <div className="flex justify-between items-center mt-6">
                        <div className="text-sm text-gray-600">
                            Page {pagination.page} of {pagination.pages} ({pagination.total} orders)
                        </div>
                        <div className="flex space-x-2">
                            <button
                                onClick={() => setPagination(prev => ({ ...prev, page: Math.max(1, prev.page - 1) }))}
                                disabled={pagination.page === 1}
                                className="px-3 py-1 rounded border hover:bg-gray-50 disabled:opacity-50"
                            >
                                Previous
                            </button>
                            <button
                                onClick={() => setPagination(prev => ({ ...prev, page: Math.min(pagination.pages, prev.page + 1) }))}
                                disabled={pagination.page === pagination.pages}
                                className="px-3 py-1 rounded border hover:bg-gray-50 disabled:opacity-50"
                            >
                                Next
                            </button>
                        </div>
                    </div>
                </>
            )}

            {/* Order Details Modal */}
            {viewOrder && (
                <OrderDetailsModal
                    order={viewOrder}
                    onClose={() => setViewOrder(null)}
                    onStatusUpdate={handleStatusUpdate}
                    onRefresh={fetchOrders}
                />
            )}
        </div>
    );
};

export default OrderManagement;
