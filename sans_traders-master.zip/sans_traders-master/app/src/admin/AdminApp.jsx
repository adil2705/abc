import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AdminLogin from './pages/AdminLogin';
import Dashboard from './pages/Dashboard';
import OrderManagement from './pages/OrderManagement';
import ManageUsers from './pages/Users/ManageUsers';
import AddUser from './pages/Users/AddUser';
import EditUser from './pages/Users/EditUser';
import AddProduct from './pages/Products/AddProduct';
import ManageProducts from './pages/Products/ManageProducts';
import EditProduct from './pages/Products/EditProduct';
import ManageCategories from './pages/ManageCategories';
import CreateOrder from './pages/Orders/CreateOrder';
import AdminLayout from './components/AdminLayout';

const ProtectedRoute = ({ children }) => {
    const token = localStorage.getItem('admin_token');
    return token ? children : <Navigate to="/admin/login" />;
};

function AdminApp() {
    const token = localStorage.getItem('admin_token');

    return (
        <Routes>
            <Route path="/login" element={
                token ? (
                    JSON.parse(localStorage.getItem('admin_user') || '{}').group_id == 5
                        ? <Navigate to="/admin/orders/create" />
                        : <Navigate to="/admin/dashboard" />
                ) : <AdminLogin />
            } />
            <Route
                path="/dashboard"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <Dashboard />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/orders"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <OrderManagement />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/users/manage"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <ManageUsers />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/users/add"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <AddUser />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/users/edit/:id"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <EditUser />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/products/add"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <AddProduct />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/products/manage"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <ManageProducts />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/products/edit/:id"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <EditProduct />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/categories/manage"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <ManageCategories />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route
                path="/orders/create"
                element={
                    <ProtectedRoute>
                        <AdminLayout>
                            <CreateOrder />
                        </AdminLayout>
                    </ProtectedRoute>
                }
            />
            <Route path="/" element={
                token ? (
                    JSON.parse(localStorage.getItem('admin_user') || '{}').group_id == 5
                        ? <Navigate to="/admin/orders/create" />
                        : <Navigate to="/admin/dashboard" />
                ) : <Navigate to="/admin/login" />
            } />
        </Routes>
    );
}

export default AdminApp;
