import React, { createContext, useState, useContext, useEffect } from 'react';
import api from '../utils/api';

const AuthContext = createContext();

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within AuthProvider');
    }
    return context;
};

export const AuthProvider = ({ children }) => {
    const [buyer, setBuyer] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const token = localStorage.getItem('token');
        const savedBuyer = localStorage.getItem('buyer');

        if (token && savedBuyer) {
            setBuyer(JSON.parse(savedBuyer));
        }
        setLoading(false);
    }, []);

    const login = async (email, password) => {
        const response = await api.post('/auth/login.php', { email, password });
        const { token, buyer } = response.data;

        localStorage.setItem('token', token);
        localStorage.setItem('buyer', JSON.stringify(buyer));
        setBuyer(buyer);

        return response.data;
    };

    const signup = async (name, email, password, phone, address) => {
        const response = await api.post('/auth/signup.php', {
            name,
            email,
            password,
            phone,
            address,
        });
        const { token, buyer } = response.data;

        localStorage.setItem('token', token);
        localStorage.setItem('buyer', JSON.stringify(buyer));
        setBuyer(buyer);

        return response.data;
    };

    const logout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('buyer');
        setBuyer(null);
    };

    return (
        <AuthContext.Provider value={{ buyer, login, signup, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};
