import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useCart } from '../context/CartContext';

const ProductDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { addToCart } = useCart();
    const [product, setProduct] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const [loading, setLoading] = useState(true);
    const [added, setAdded] = useState(false);

    useEffect(() => {
        fetchProduct();
    }, [id]);

    const fetchProduct = async () => {
        try {
            const response = await api.get(`/products/detail.php?id=${id}`);
            setProduct(response.data.product);
        } catch (error) {
            console.error('Failed to fetch product:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleAddToCart = () => {
        addToCart(product, quantity);
        setAdded(true);
        setTimeout(() => setAdded(false), 2000);
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            </div>
        );
    }

    if (!product) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <p className="text-gray-500 text-lg mb-4">Product not found</p>
                    <button onClick={() => navigate('/products')} className="btn-primary">
                        Back to Products
                    </button>
                </div>
            </div>
        );
    }

    const price = parseFloat(product.price);
    const discount = product.discount ? product.discount.replace('%', '') : '0';
    const discountPercent = parseFloat(discount);

    return (
        <div className="min-h-screen bg-gray-50 py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <button
                    onClick={() => navigate('/products')}
                    className="mb-4 text-primary-600 hover:text-primary-700 flex items-center"
                >
                    <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                    Back to Products
                </button>

                <div className="card p-6">
                    <div className="grid md:grid-cols-2 gap-8">
                        {/* Product Image */}
                        <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                            {product.image && product.image !== '' && !product.image.includes('not select') ? (
                                <img
                                    src={`http://localhost/sans_traders-master${product.image}`}
                                    alt={product.name}
                                    className="w-full h-full object-contain rounded-lg p-4 bg-white"
                                    onError={(e) => {
                                        e.target.onerror = null;
                                        e.target.src = 'https://placehold.co/600x600?text=No+Image';
                                    }}
                                />
                            ) : (
                                <div className="text-gray-400">
                                    <svg className="w-32 h-32" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path
                                            strokeLinecap="round"
                                            strokeLinejoin="round"
                                            strokeWidth={2}
                                            d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"
                                        />
                                    </svg>
                                </div>
                            )}
                        </div>

                        {/* Product Info */}
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
                            {product.brand_name && (
                                <p className="text-gray-600 mb-4">Brand: {product.brand_name}</p>
                            )}
                            {product.category_name && (
                                <p className="text-gray-600 mb-4">Category: {product.category_name}</p>
                            )}

                            <div className="mb-6">
                                {discountPercent > 0 ? (
                                    <>
                                        <div className="flex items-baseline space-x-3 mb-2">
                                            <span className="text-4xl font-bold text-primary-600">
                                                ₹{(price * (1 - discountPercent / 100)).toFixed(2)}
                                            </span>
                                            <span className="text-2xl text-gray-500 line-through">
                                                ₹{price.toFixed(2)}
                                            </span>
                                        </div>
                                        <div className="flex items-center space-x-2">
                                            <span className="inline-block text-sm bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">
                                                Save {discount}%
                                            </span>
                                            <span className="text-sm text-gray-600">
                                                You save ₹{(price * discountPercent / 100).toFixed(2)}
                                            </span>
                                        </div>
                                    </>
                                ) : (
                                    <span className="text-4xl font-bold text-primary-600">₹{price.toFixed(2)}</span>
                                )}
                            </div>

                            {product.sku && (
                                <p className="text-gray-600 mb-4">SKU: {product.sku}</p>
                            )}

                            {product.description && product.description !== '' && (
                                <div className="mb-6">
                                    <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
                                    <div
                                        className="text-gray-600"
                                        dangerouslySetInnerHTML={{ __html: product.description }}
                                    />
                                </div>
                            )}

                            <div className="mb-6">
                                <p className="text-sm text-gray-500">
                                    SKU: {product.sku}
                                </p>
                            </div>

                            <div className="mb-6">
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Quantity
                                </label>
                                <div className="flex items-center space-x-3">
                                    <button
                                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                                        className="w-10 h-10 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-100"
                                    >
                                        -
                                    </button>
                                    <span className="text-xl font-semibold w-12 text-center">{quantity}</span>
                                    <button
                                        onClick={() => setQuantity(quantity + 1)}
                                        className="w-10 h-10 rounded-lg border border-gray-300 flex items-center justify-center hover:bg-gray-100"
                                    >
                                        +
                                    </button>
                                </div>
                            </div>

                            <button
                                onClick={handleAddToCart}
                                className={`w-full py-3 px-6 rounded-lg font-semibold text-lg transition-all duration-200 ${added
                                    ? 'bg-green-500 text-white'
                                    : 'bg-primary-600 hover:bg-primary-700 text-white'
                                    }`}
                            >
                                {added ? '✓ Added to Cart' : 'Add to Cart'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductDetail;
