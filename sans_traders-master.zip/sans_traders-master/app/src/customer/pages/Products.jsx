import React, { useState, useEffect } from 'react';
import api from '../utils/api';
import ProductCard from '../components/ProductCard';

const Products = () => {
    const [products, setProducts] = useState([]);
    const [filters, setFilters] = useState({ categories: [] });
    const [selectedCategory, setSelectedCategory] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true);
    const [page, setPage] = useState(1);
    const [pagination, setPagination] = useState(null);
    const [showCategories, setShowCategories] = useState(false);

    useEffect(() => {
        fetchFilters();
    }, []);

    useEffect(() => {
        fetchProducts();
    }, [page, selectedCategory, searchTerm]);

    const fetchFilters = async () => {
        try {
            const response = await api.get('/products/filters.php');
            setFilters(response.data);
        } catch (error) {
            console.error('Failed to fetch filters:', error);
        }
    };

    const fetchProducts = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams({
                page: page.toString(),
                limit: '20',
            });

            if (searchTerm) params.append('search', searchTerm);
            if (selectedCategory) params.append('category', selectedCategory);

            const response = await api.get(`/products/list.php?${params}`);
            setProducts(response.data.products);
            setPagination(response.data.pagination);
        } catch (error) {
            console.error('Failed to fetch products:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleSearch = (e) => {
        e.preventDefault();
        setPage(1);
        fetchProducts();
    };

    return (
        <div className="min-h-screen bg-gray-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
                <div className="flex flex-col md:flex-row gap-8">
                    {/* Filters Sidebar */}
                    <div className="w-full md:w-64 flex-shrink-0">
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <h2 className="text-lg font-bold text-gray-900 mb-4">Filters</h2>

                            {/* Search */}
                            <div className="mb-6">
                                <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
                                <form onSubmit={handleSearch}>
                                    <div className="relative">
                                        <input
                                            type="text"
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                            placeholder="Search products..."
                                            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all"
                                        />
                                        <svg className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                        </svg>
                                    </div>
                                </form>
                            </div>

                            {/* Divider */}
                            <div className="border-t border-gray-200 my-6"></div>

                            {/* Categories - Collapsible on Mobile */}
                            <div>
                                <div className="flex items-center justify-between mb-3">
                                    <h3 className="font-semibold text-gray-900">Categories</h3>
                                    <button
                                        onClick={() => setShowCategories(!showCategories)}
                                        className="md:hidden text-gray-500 hover:text-gray-700"
                                    >
                                        <svg
                                            className={`w-5 h-5 transition-transform ${showCategories ? 'rotate-180' : ''}`}
                                            fill="none"
                                            stroke="currentColor"
                                            viewBox="0 0 24 24"
                                        >
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                        </svg>
                                    </button>
                                </div>
                                <div className={`space-y-2 max-h-48 overflow-y-auto custom-scrollbar ${showCategories ? 'block' : 'hidden md:block'}`}>
                                    <label className="flex items-center space-x-2 cursor-pointer group">
                                        <input
                                            type="radio"
                                            name="category"
                                            value=""
                                            checked={selectedCategory === ''}
                                            onChange={() => { setSelectedCategory(''); setPage(1); }}
                                            className="form-radio text-primary-600 focus:ring-primary-500 rounded-full"
                                        />
                                        <span className={`text-sm group-hover:text-primary-600 transition-colors ${selectedCategory === '' ? 'text-primary-700 font-medium' : 'text-gray-600'}`}>
                                            All Categories
                                        </span>
                                    </label>
                                    {filters.categories.map((cat) => (
                                        <label key={cat.id} className="flex items-center space-x-2 cursor-pointer group">
                                            <input
                                                type="radio"
                                                name="category"
                                                value={cat.id}
                                                checked={selectedCategory == cat.id}
                                                onChange={() => { setSelectedCategory(cat.id); setPage(1); }}
                                                className="form-radio text-primary-600 focus:ring-primary-500 rounded-full"
                                            />
                                            <span className={`text-sm group-hover:text-primary-600 transition-colors ${selectedCategory == cat.id ? 'text-primary-700 font-medium' : 'text-gray-600'}`}>
                                                {cat.name}
                                            </span>
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {(selectedCategory || searchTerm) && (
                                <button
                                    onClick={() => {
                                        setSelectedCategory('');
                                        setSearchTerm('');
                                        setPage(1);
                                    }}
                                    className="w-full py-2 px-4 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
                                >
                                    Clear Filters
                                </button>
                            )}
                        </div>
                    </div>

                    {/* Product Grid */}
                    <div className="flex-1">
                        <div className="mb-6 flex justify-between items-center">
                            <h1 className="text-2xl font-bold text-gray-900">
                                {searchTerm ? `Search Results for "${searchTerm}"` : 'Our Collection'}
                            </h1>
                            <span className="text-gray-500 text-sm">
                                {pagination?.total || 0} Products
                            </span>
                        </div>

                        {loading ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                {[...Array(6)].map((_, i) => (
                                    <div key={i} className="aspect-[3/4] bg-gray-100 rounded-xl animate-pulse"></div>
                                ))}
                            </div>
                        ) : products.length === 0 ? (
                            <div className="text-center py-16 bg-white rounded-xl border border-gray-100">
                                <div className="text-gray-300 mb-4">
                                    <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                    </svg>
                                </div>
                                <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
                                <p className="text-gray-500">Try adjusting your search or filters to find what you're looking for.</p>
                                <button
                                    onClick={() => { setSelectedCategory(''); setSearchTerm(''); }}
                                    className="mt-4 text-primary-600 hover:text-primary-700 font-medium"
                                >
                                    Clear all filters
                                </button>
                            </div>
                        ) : (
                            <>
                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                                    {products.map((product) => (
                                        <ProductCard key={product.id} product={product} />
                                    ))}
                                </div>

                                {/* Pagination */}
                                {pagination && pagination.pages > 1 && (
                                    <div className="flex justify-center items-center space-x-2">
                                        <button
                                            onClick={() => setPage(page - 1)}
                                            disabled={page === 1}
                                            className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                        >
                                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                                            </svg>
                                        </button>
                                        <div className="flex space-x-1">
                                            {[...Array(pagination.pages)].map((_, i) => {
                                                const p = i + 1;
                                                if (
                                                    p === 1 ||
                                                    p === pagination.pages ||
                                                    (p >= page - 1 && p <= page + 1)
                                                ) {
                                                    return (
                                                        <button
                                                            key={p}
                                                            onClick={() => setPage(p)}
                                                            className={`w-10 h-10 rounded-lg font-medium transition-colors ${page === p
                                                                ? 'bg-primary-600 text-white shadow-sm'
                                                                : 'text-gray-600 hover:bg-gray-50 border border-gray-200'
                                                                }`}
                                                        >
                                                            {p}
                                                        </button>
                                                    );
                                                } else if (
                                                    (p === page - 2 && page > 3) ||
                                                    (p === page + 2 && page < pagination.pages - 2)
                                                ) {
                                                    return <span key={p} className="flex items-end px-1 text-gray-400">...</span>;
                                                }
                                                return null;
                                            })}
                                        </div>
                                        <button
                                            onClick={() => setPage(page + 1)}
                                            disabled={page === pagination.pages}
                                            className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                                        >
                                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                                            </svg>
                                        </button>
                                    </div>
                                )}
                            </>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Products;
