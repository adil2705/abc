import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useNotification } from '../context/NotificationContext';
import api from '../utils/api';

const Checkout = () => {
    const navigate = useNavigate();
    const { cart, getCartTotal, clearCart, getDiscountedPrice } = useCart();
    const { buyer } = useAuth();
    const { showNotification } = useNotification();
    const [deliveryAddress, setDeliveryAddress] = useState(buyer?.address || '');
    const [orderNotes, setOrderNotes] = useState('');

    // New fields for "Order for someone else"
    const [isGift, setIsGift] = useState(false);
    const [recipientName, setRecipientName] = useState('');
    const [recipientPhone, setRecipientPhone] = useState('');

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            const items = cart.map((item) => ({
                product_id: item.id,
                qty: item.quantity,
            }));

            const response = await api.post('/orders/create.php', {
                items,
                delivery_address: deliveryAddress,
                order_notes: orderNotes,
                shipping_name: isGift ? recipientName : buyer?.name,
                shipping_phone: isGift ? recipientPhone : buyer?.phone
            });

            showNotification('Order placed successfully!', 'success');
            clearCart();
            navigate(`/order-success/${response.data.order.bill_no}`);
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to place order. Please try again.');
            showNotification(err.response?.data?.error || 'Failed to place order', 'error');
        } finally {
            setLoading(false);
        }
    };

    if (cart.length === 0) {
        navigate('/cart');
        return null;
    }

    return (
        <div className="min-h-screen bg-gray-50 py-6">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-6">Checkout</h1>

                {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                        {error}
                    </div>
                )}

                <div className="grid md:grid-cols-2 gap-6">
                    {/* Order Form */}
                    <div className="card p-6">
                        <h2 className="text-xl font-semibold text-gray-900 mb-4">Delivery Information</h2>
                        <form onSubmit={handleSubmit} className="space-y-4">

                            {/* Order for someone else toggle */}
                            <div className="flex items-center mb-4">
                                <input
                                    type="checkbox"
                                    id="orderForSomeoneElse"
                                    checked={isGift}
                                    onChange={(e) => setIsGift(e.target.checked)}
                                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                                />
                                <label htmlFor="orderForSomeoneElse" className="ml-2 block text-sm text-gray-900 font-medium cursor-pointer">
                                    Order for someone else?
                                </label>
                            </div>

                            {isGift && (
                                <div className="space-y-4 p-4 bg-gray-50 rounded-lg border border-gray-200 animate-fade-in">
                                    <h3 className="text-sm font-semibold text-gray-700">Recipient Details</h3>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">
                                            Recipient Name *
                                        </label>
                                        <input
                                            type="text"
                                            value={recipientName}
                                            onChange={(e) => setRecipientName(e.target.value)}
                                            className="input-field"
                                            placeholder="Recipient's Name"
                                            required={isGift}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">
                                            Recipient Phone *
                                        </label>
                                        <input
                                            type="tel"
                                            value={recipientPhone}
                                            onChange={(e) => setRecipientPhone(e.target.value)}
                                            className="input-field"
                                            placeholder="Recipient's Phone"
                                            required={isGift}
                                        />
                                    </div>
                                </div>
                            )}

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Delivery Address *
                                </label>
                                <textarea
                                    value={deliveryAddress}
                                    onChange={(e) => setDeliveryAddress(e.target.value)}
                                    className="input-field"
                                    rows="3"
                                    placeholder="Enter complete delivery address"
                                    required
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Order Notes (Optional)
                                </label>
                                <textarea
                                    value={orderNotes}
                                    onChange={(e) => setOrderNotes(e.target.value)}
                                    className="input-field"
                                    rows="2"
                                    placeholder="Any special instructions for delivery?"
                                />
                            </div>

                            <button
                                type="submit"
                                disabled={loading}
                                className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed py-3 font-semibold text-lg"
                            >
                                {loading ? 'Placing Order...' : 'Place Order'}
                            </button>
                        </form>
                    </div>

                    {/* Order Summary */}
                    <div className="card p-6">
                        <h2 className="text-xl font-semibold text-gray-900 mb-4">Order Summary</h2>
                        <div className="space-y-3 mb-6">
                            {cart.map((item) => (
                                <div key={item.id} className="flex justify-between text-sm">
                                    <span className="text-gray-600">
                                        {item.name} x {item.quantity}
                                    </span>
                                    <span className="font-medium">
                                        ₹{(getDiscountedPrice(item) * item.quantity).toFixed(2)}
                                    </span>
                                </div>
                            ))}
                        </div>
                        <div className="border-t border-gray-200 pt-4">
                            <div className="flex justify-between items-center">
                                <span className="text-lg font-semibold text-gray-900">Total</span>
                                <span className="text-2xl font-bold text-primary-600">
                                    ₹{getCartTotal().toFixed(2)}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Place Order Button - Bottom */}

            </div>
        </div>
    );
};

export default Checkout;
