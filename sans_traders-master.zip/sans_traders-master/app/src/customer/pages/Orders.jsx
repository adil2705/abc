import React, { useState, useEffect } from 'react';
import api from '../utils/api';

const Orders = () => {
    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            const response = await api.get('/orders/buyer-orders.php');
            setOrders(response.data.orders);
        } catch (error) {
            console.error('Failed to fetch orders:', error);
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status) => {
        const colors = {
            pending: 'bg-yellow-100 text-yellow-800',
            confirmed: 'bg-blue-100 text-blue-800',
            processing: 'bg-purple-100 text-purple-800',
            shipped: 'bg-indigo-100 text-indigo-800',
            delivered: 'bg-green-100 text-green-800',
            cancelled: 'bg-red-100 text-red-800',
        };
        return colors[status] || 'bg-gray-100 text-gray-800';
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
            </div>
        );
    }

    if (orders.length === 0) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="text-center">
                    <svg
                        className="w-24 h-24 text-gray-300 mx-auto mb-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                        />
                    </svg>
                    <h2 className="text-2xl font-bold text-gray-800 mb-2">No orders yet</h2>
                    <p className="text-gray-600">Your order history will appear here</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 py-6">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-6">My Orders</h1>

                <div className="space-y-4">
                    {orders.map((order) => (
                        <div key={order.id} className="card p-6">
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                                <div>
                                    <h3 className="font-semibold text-gray-900">Order #{order.bill_no}</h3>
                                    <p className="text-sm text-gray-600">
                                        {new Date(order.date_time * 1000).toLocaleDateString('en-IN', {
                                            year: 'numeric',
                                            month: 'long',
                                            day: 'numeric',
                                        })}
                                    </p>
                                </div>
                                <span
                                    className={`mt-2 sm:mt-0 inline-block px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(
                                        order.order_status
                                    )}`}
                                >
                                    {order.order_status.charAt(0).toUpperCase() + order.order_status.slice(1)}
                                </span>
                            </div>

                            <div className="border-t border-gray-200 pt-4 mb-4">
                                <h4 className="font-medium text-gray-900 mb-2">Items ({order.item_count})</h4>
                                <div className="space-y-2">
                                    {order.items.map((item) => (
                                        <div key={item.id} className="flex justify-between text-sm">
                                            <span className="text-gray-600">
                                                {item.product_name} x {item.qty}
                                            </span>
                                            <span className="font-medium">₹{parseFloat(item.amount).toFixed(2)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="border-t border-gray-200 pt-4">
                                <div className="flex justify-between items-center">
                                    <span className="text-xl font-bold text-primary-600">
                                        ₹{parseFloat(order.net_amount).toFixed(2)}
                                    </span>
                                </div>
                                <div className="mt-4 flex justify-end space-x-3">

                                    <button
                                        onClick={() => window.open(`${import.meta.env.VITE_API_BASE_URL}/orders/invoice.php?id=${order.id}`, '_blank')}
                                        className="bg-primary-600 text-white px-4 py-2 rounded hover:bg-primary-700 transition"
                                    >
                                        View Invoice
                                    </button>
                                </div>
                            </div>

                            {order.delivery_address && (
                                <div className="mt-4 text-sm text-gray-600">
                                    <span className="font-medium">Delivery Address:</span> {order.delivery_address}
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default Orders;
