import React from 'react';

import { useCart } from '../context/CartContext';

const ProductCard = ({ product }) => {
    const { addToCart } = useCart();
    const [added, setAdded] = React.useState(false);

    const handleAddToCart = (e) => {
        e.preventDefault();
        addToCart(product, 1);
        setAdded(true);
        setTimeout(() => setAdded(false), 2000);
    };

    const price = parseFloat(product.price);
    const discount = product.discount ? product.discount.replace('%', '') : '0';
    const discountPercent = parseFloat(discount);

    return (
        <div className="card hover:shadow-lg transition-shadow duration-300 overflow-hidden">
            {/* Product Image */}
            <div className="aspect-square bg-gray-100 flex items-center justify-center overflow-hidden">
                {product.image && product.image !== '' ? (
                    <img
                        src={`http://localhost/sans_traders-master${product.image}`}
                        alt={product.name}
                        className="w-full h-full object-contain p-2"
                        onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = 'https://placehold.co/400x400?text=No+Image';
                        }}
                    />
                ) : (
                    <div className="text-gray-300">
                        <svg className="w-24 h-24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth="2"
                                d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                            />
                        </svg>
                    </div>
                )}
            </div>
            <div className="p-4">
                <h3 className="font-semibold text-gray-800 mb-1 line-clamp-2 min-h-[3rem]">
                    {product.name}
                </h3>
                {product.brand_name && (
                    <p className="text-xs text-gray-500 mb-2">{product.brand_name}</p>
                )}
                <div className="mb-3">
                    {discountPercent > 0 ? (
                        <>
                            <div className="flex items-baseline space-x-2 mb-1">
                                <span className="text-xl font-bold text-primary-600">
                                    ₹{(price * (1 - discountPercent / 100)).toFixed(2)}
                                </span>
                                <span className="text-sm text-gray-500 line-through">
                                    ₹{price.toFixed(2)}
                                </span>
                            </div>
                            <span className="inline-block text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">
                                Save {discount}%
                            </span>
                        </>
                    ) : (
                        <span className="text-xl font-bold text-primary-600">₹{price.toFixed(2)}</span>
                    )}
                </div>
                <button
                    onClick={handleAddToCart}
                    className={`w-full py-2 px-4 rounded-lg font-medium transition-all duration-200 ${added
                        ? 'bg-green-500 text-white'
                        : 'bg-primary-600 hover:bg-primary-700 text-white'
                        }`}
                >
                    {added ? '✓ Added' : 'Add to Cart'}
                </button>
            </div>
        </div>
    );
};

export default ProductCard;
