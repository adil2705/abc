import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CustomerApp from './customer/CustomerApp';
import AdminApp from './admin/AdminApp';

function App() {
    return (
        <BrowserRouter>
            <Routes>
                {/* Admin routes - all prefixed with /admin */}
                <Route path="/admin/*" element={<AdminApp />} />

                {/* Customer routes - at root level */}
                <Route path="/*" element={<CustomerApp />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;
