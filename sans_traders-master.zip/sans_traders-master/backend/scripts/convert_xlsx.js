const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');

const inputPath = path.resolve(__dirname, '../../item.xlsx');
const outputPath = path.resolve(__dirname, 'item.csv');

console.log(`Reading from: ${inputPath}`);

if (!fs.existsSync(inputPath)) {
    console.error(`Error: File not found at ${inputPath}`);
    process.exit(1);
}

const workbook = XLSX.readFile(inputPath);
const sheetName = workbook.SheetNames[0];
const worksheet = workbook.Sheets[sheetName];

const csvContent = XLSX.utils.sheet_to_csv(worksheet);

fs.writeFileSync(outputPath, csvContent);

console.log(`Successfully converted to: ${outputPath}`);
