<?php
require_once __DIR__ . '/../config/database.php';

try {
    // 1. Delete items where product_id does not exist in products table
    $sql = "DELETE FROM orders_item WHERE product_id NOT IN (SELECT id FROM products)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $deletedCount = $stmt->rowCount();
    
    echo "Deleted $deletedCount orphaned items (invalid product_id).\n";

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
