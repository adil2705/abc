<?php
require_once __DIR__ . '/../config/database.php';

// Get the specific order mentioned by user
$billNo = 'BILPR-9B14';
$stmt = $pdo->prepare("SELECT * FROM orders WHERE bill_no = ?");
$stmt->execute([$billNo]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die("Order $billNo not found");
}

echo "<h2>Order Debug Report for $billNo</h2>";
echo "<pre>";

echo "\n=== ORDER DETAILS ===\n";
print_r($order);

echo "\n=== ORDER ITEMS (Raw from orders_item table) ===\n";
$stmt = $pdo->prepare("SELECT * FROM orders_item WHERE order_id = ?");
$stmt->execute([$order['id']]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($items);

echo "\n=== ORDER ITEMS (With Product Details) ===\n";
$stmt = $pdo->prepare("
    SELECT oi.*, p.name as product_name, p.sku as product_sku, p.price as product_price
    FROM orders_item oi
    LEFT JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$stmt->execute([$order['id']]);
$itemsWithProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($itemsWithProducts);

echo "\n=== PRODUCT DETAILS ===\n";
foreach ($items as $item) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$item['product_id']]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "\nProduct ID {$item['product_id']}:\n";
    print_r($product);
}

echo "\n=== ANALYSIS ===\n";
echo "Total items in order: " . count($items) . "\n";
echo "Expected items: 1 (JOY MANGO FACEWASH)\n";
echo "Actual items found:\n";
foreach ($itemsWithProducts as $item) {
    echo "  - {$item['product_name']} (ID: {$item['product_id']}) x {$item['qty']} = ₹{$item['amount']}\n";
}

echo "</pre>";
?>
