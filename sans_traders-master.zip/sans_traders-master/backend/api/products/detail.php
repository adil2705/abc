<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid product ID']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT p.*, 
        GROUP_CONCAT(DISTINCT b.name) as brand_name,
        GROUP_CONCAT(DISTINCT c.name) as category_name
        FROM products p
        LEFT JOIN brands b ON FIND_IN_SET(b.id, REPLACE(REPLACE(p.brand_id, '[', ''), ']', ''))
        LEFT JOIN categories c ON FIND_IN_SET(c.id, REPLACE(REPLACE(p.category_id, '[', ''), ']', ''))
        WHERE p.id = ?
        GROUP BY p.id
    ");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    if (!$product) {
        http_response_code(404);
        echo json_encode(['error' => 'Product not found']);
        exit;
    }
    
    http_response_code(200);
    echo json_encode(['product' => $product]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch product']);
}
