<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Authenticate admin
authenticateAdmin();

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields - only name, price, and brand_name are required now
$required = ['name', 'price', 'brand_name'];
foreach ($required as $field) {
    if (!isset($data[$field]) || empty(trim($data[$field]))) {
        http_response_code(400);
        echo json_encode(['error' => ucfirst($field) . ' is required']);
        exit;
    }
}

$name = trim($data['name']);
$price = floatval($data['price']);
$brandName = trim($data['brand_name']);
$discount = isset($data['discount']) ? trim($data['discount']) : '0%';

try {
    // Find or create brand
    $stmt = $pdo->prepare("SELECT id FROM brands WHERE name = ?");
    $stmt->execute([$brandName]);
    $brand = $stmt->fetch();
    
    if ($brand) {
        $brand_id = $brand['id'];
    } else {
        $stmt = $pdo->prepare("INSERT INTO brands (name, active) VALUES (?, 1)");
        $stmt->execute([$brandName]);
        $brand_id = $pdo->lastInsertId();
    }

    // Use defaults for category and store if not provided
    $category_id = isset($data['category_id']) && !empty($data['category_id']) 
        ? intval($data['category_id']) 
        : 16; // Default category ID (OTHER)
    $store_id = isset($data['store_id']) && !empty($data['store_id']) 
        ? intval($data['store_id']) 
        : 3; // Default store ID (SANS Traders)

    // Get image path if provided
    $image = isset($data['image']) ? trim($data['image']) : '';

    // Generate SKU
    $sku = 'SKU-' . strtoupper(substr(md5(uniqid()), 0, 8));
    $stmt = $pdo->prepare("
        INSERT INTO products (
            name, sku, price, brand_id, category_id, store_id, 
            discount, availability, image
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
    ");
    
    $stmt->execute([
        $name,
        $sku,
        $price,
        $brand_id,
        $category_id,
        $store_id,
        $discount,
        $image
    ]);
    
    $productId = $pdo->lastInsertId();
    
    http_response_code(201);
    echo json_encode([
        'message' => 'Product created successfully',
        'product_id' => $productId,
        'sku' => $sku
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to create product']);
}
?>
