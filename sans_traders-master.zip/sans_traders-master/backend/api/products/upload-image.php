<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';
require_once __DIR__ . '/../../utils/ImageUploader.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Authenticate admin
authenticateAdmin();

// Check if file was uploaded
if (!isset($_FILES['image'])) {
    http_response_code(400);
    echo json_encode(['error' => 'No image file provided']);
    exit;
}

// Get category from request (default to 'other')
$category = isset($_POST['category']) ? $_POST['category'] : 'other';

// Upload image
$uploader = new ImageUploader();
$result = $uploader->upload($_FILES['image'], $category);

if ($result['success']) {
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'path' => $result['path'],
        'message' => 'Image uploaded successfully'
    ]);
} else {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $result['error']
    ]);
}
