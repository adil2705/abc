<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

authenticateAdmin();

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['id']) || empty($data['name'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Category ID and name are required']);
    exit;
}

try {
    $stmt = $pdo->prepare("UPDATE categories SET name = ?, active = ? WHERE id = ?");
    $stmt->execute([
        $data['name'],
        $data['active'] ?? 1,
        $data['id']
    ]);
    
    http_response_code(200);
    echo json_encode(['message' => 'Category updated successfully']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to update category']);
}
?>
