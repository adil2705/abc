<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Authenticate admin
$admin = authenticateAdmin();

try {
    // Get today's date range
    $todayStart = strtotime('today midnight');
    $todayEnd = strtotime('tomorrow midnight') - 1;
    
    // Total orders today
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM orders WHERE date_time >= ? AND date_time <= ?");
    $stmt->execute([$todayStart, $todayEnd]);
    $todayOrders = $stmt->fetch()['count'];
    
    // Total sales today (excluding cancelled)
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(net_amount), 0) as total FROM orders WHERE date_time >= ? AND date_time <= ? AND order_status != 'cancelled'");
    $stmt->execute([$todayStart, $todayEnd]);
    $todaySales = $stmt->fetch()['total'];
    
    // Pending orders count
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM orders WHERE order_status = 'pending'");
    $stmt->execute();
    $pendingOrders = $stmt->fetch()['count'];
    
    // Total products
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM products WHERE availability = 1");
    $stmt->execute();
    $totalProducts = $stmt->fetch()['count'];
    
    // Total buyers
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM buyers");
    $stmt->execute();
    $totalBuyers = $stmt->fetch()['count'];

    // Total Sale Payment (All time, excluding cancelled)
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(net_amount), 0) as total FROM orders WHERE order_status != 'cancelled'");
    $stmt->execute();
    $totalSalePayment = $stmt->fetch()['total'];

    // Received Payment (All time, Paid orders, excluding cancelled)
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(net_amount), 0) as total FROM orders WHERE paid_status = 1 AND order_status != 'cancelled'");
    $stmt->execute();
    $receivedPayment = $stmt->fetch()['total'];
    
    // Recent orders (last 10)
    $stmt = $pdo->prepare("
        SELECT o.*, b.name as buyer_name, b.email as buyer_email,
        COUNT(oi.id) as item_count
        FROM orders o
        LEFT JOIN buyers b ON o.buyer_id = b.id
        LEFT JOIN orders_item oi ON o.id = oi.order_id
        GROUP BY o.id
        ORDER BY o.date_time DESC
        LIMIT 10
    ");
    $stmt->execute();
    $recentOrders = $stmt->fetchAll();
    
    // Order status breakdown
    $stmt = $pdo->prepare("
        SELECT order_status, COUNT(*) as count 
        FROM orders 
        GROUP BY order_status
    ");
    $stmt->execute();
    $statusBreakdown = $stmt->fetchAll();
    
    http_response_code(200);
    echo json_encode([
        'summary' => [
            'today_orders' => intval($todayOrders),
            'today_sales' => floatval($todaySales),
            'pending_orders' => intval($pendingOrders),
            'total_products' => intval($totalProducts),
            'total_buyers' => intval($totalBuyers),
            'total_sale_payment' => floatval($totalSalePayment),
            'received_payment' => floatval($receivedPayment)
        ],
        'recent_orders' => $recentOrders,
        'status_breakdown' => $statusBreakdown
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch dashboard data']);
}
