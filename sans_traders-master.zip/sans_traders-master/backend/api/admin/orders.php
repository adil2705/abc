<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

// Authenticate admin
$admin = authenticateAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get query parameters
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $limit = isset($_GET['limit']) ? min(50, max(1, intval($_GET['limit']))) : 20;
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $date = isset($_GET['date']) ? trim($_GET['date']) : '';
    
    $offset = ($page - 1) * $limit;
    
    try {
        // Build query
        $sql = "SELECT o.*, b.name as buyer_name, b.email as buyer_email, b.phone as buyer_phone,
                COUNT(oi.id) as item_count
                FROM orders o
                LEFT JOIN buyers b ON o.buyer_id = b.id
                LEFT JOIN orders_item oi ON o.id = oi.order_id
                WHERE 1=1";
        
        $params = [];
        
        // Add status filter
        if ($status && in_array($status, ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'])) {
            $sql .= " AND o.order_status = ?";
            $params[] = $status;
        }
        
        // Add search filter
        if ($search) {
            $sql .= " AND (o.bill_no LIKE ? OR o.customer_name LIKE ? OR b.email LIKE ?)";
            $searchTerm = "%$search%";
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        // Add date filter
        if ($date) {
            $dateStart = strtotime($date . ' 00:00:00');
            $dateEnd = strtotime($date . ' 23:59:59');
            $sql .= " AND o.date_time >= ? AND o.date_time <= ?";
            $params[] = $dateStart;
            $params[] = $dateEnd;
        }
        
        $sql .= " GROUP BY o.id ORDER BY o.date_time DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $orders = $stmt->fetchAll();
        
        // Get order items for each order
        foreach ($orders as &$order) {
            $stmt = $pdo->prepare("
                SELECT oi.*, p.name as product_name, p.sku as product_sku, p.image as product_image
                FROM orders_item oi
                LEFT JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = ?
            ");
            $stmt->execute([$order['id']]);
            $order['items'] = $stmt->fetchAll();
        }
        
        // Get total count
        $countSql = "SELECT COUNT(DISTINCT o.id) as total FROM orders o LEFT JOIN buyers b ON o.buyer_id = b.id WHERE 1=1";
        $countParams = [];
        
        if ($status && in_array($status, ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'])) {
            $countSql .= " AND o.order_status = ?";
            $countParams[] = $status;
        }
        
        if ($search) {
            $countSql .= " AND (o.bill_no LIKE ? OR o.customer_name LIKE ? OR b.email LIKE ?)";
            $countParams[] = $searchTerm;
            $countParams[] = $searchTerm;
            $countParams[] = $searchTerm;
        }
        
        if ($date) {
            $countSql .= " AND o.date_time >= ? AND o.date_time <= ?";
            $countParams[] = $dateStart;
            $countParams[] = $dateEnd;
        }
        
        $countStmt = $pdo->prepare($countSql);
        $countStmt->execute($countParams);
        $total = $countStmt->fetch()['total'];
        
        http_response_code(200);
        echo json_encode([
            'orders' => $orders,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => intval($total),
                'pages' => ceil($total / $limit)
            ]
        ]);
        
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to fetch orders']);
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Update order status or paid status
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['order_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Order ID is required']);
        exit;
    }
    
    $orderId = intval($data['order_id']);
    
    // Handle Status Update
    if (isset($data['status'])) {
        $newStatus = trim($data['status']);
        if (!in_array($newStatus, ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid status']);
            exit;
        }
        
        try {
            $stmt = $pdo->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
            $stmt->execute([$newStatus, $orderId]);
            
            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(['error' => 'Order not found']);
                exit;
            }
            
            http_response_code(200);
            echo json_encode(['message' => 'Order status updated successfully']);
            exit;
            
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to update order status']);
            exit;
        }
    }
    
    // Handle Paid Status Update
    if (isset($data['paid_status'])) {
        $paidStatus = intval($data['paid_status']); // 0 or 1
        
        try {
            $stmt = $pdo->prepare("UPDATE orders SET paid_status = ? WHERE id = ?");
            $stmt->execute([$paidStatus, $orderId]);
            
            if ($stmt->rowCount() === 0) {
                http_response_code(404);
                echo json_encode(['error' => 'Order not found']);
                exit;
            }
            
            http_response_code(200);
            echo json_encode(['message' => 'Payment status updated successfully']);
            exit;
            
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to update payment status']);
            exit;
        }
    }
    
    http_response_code(400);
    echo json_encode(['error' => 'No update data provided']);
    exit;
    
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
