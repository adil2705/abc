<?php
require_once __DIR__ . '/../config/database.php';

echo "<h2>Database Cleanup - Order Management</h2>";
echo "<pre>";

try {
    $pdo->beginTransaction();
    
    // 1. Delete all order items
    $stmt = $pdo->query("DELETE FROM orders_item");
    $itemsDeleted = $stmt->rowCount();
    echo "✓ Deleted $itemsDeleted order items\n";
    
    // 2. Delete all orders
    $stmt = $pdo->query("DELETE FROM orders");
    $ordersDeleted = $stmt->rowCount();
    echo "✓ Deleted $ordersDeleted orders\n";
    
    // 3. Reset auto-increment counters
    $pdo->exec("ALTER TABLE orders_item AUTO_INCREMENT = 1");
    $pdo->exec("ALTER TABLE orders AUTO_INCREMENT = 1");
    echo "✓ Reset auto-increment counters\n";
    
    $pdo->commit();
    
    echo "\n" . str_repeat("=", 80) . "\n";
    echo "DATABASE CLEANED SUCCESSFULLY!\n";
    echo str_repeat("=", 80) . "\n\n";
    
    echo "Summary:\n";
    echo "  - Orders deleted: $ordersDeleted\n";
    echo "  - Order items deleted: $itemsDeleted\n";
    echo "  - Database is now clean and ready for fresh orders\n\n";
    
    echo "✓ You can now test order creation with a clean slate!\n";
    
} catch (PDOException $e) {
    $pdo->rollBack();
    echo "❌ Error: " . $e->getMessage();
}

echo "</pre>";
?>
