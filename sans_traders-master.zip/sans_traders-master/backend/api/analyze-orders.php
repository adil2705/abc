<?php
require_once __DIR__ . '/../config/database.php';

echo "<h2>Orders Item Table Analysis</h2>";
echo "<pre>";

// Get all order items for recent orders
$stmt = $pdo->query("
    SELECT oi.*, o.bill_no, o.id as order_id, p.name as product_name
    FROM orders_item oi
    LEFT JOIN orders o ON oi.order_id = o.id
    LEFT JOIN products p ON oi.product_id = p.id
    ORDER BY oi.order_id DESC, oi.id ASC
    LIMIT 50
");
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Recent Order Items:\n";
echo str_repeat("=", 80) . "\n";

$currentOrderId = null;
foreach ($items as $item) {
    if ($currentOrderId !== $item['order_id']) {
        if ($currentOrderId !== null) echo "\n";
        echo "\nOrder #{$item['bill_no']} (ID: {$item['order_id']})\n";
        echo str_repeat("-", 80) . "\n";
        $currentOrderId = $item['order_id'];
    }
    echo "  Item ID: {$item['id']} | Product ID: {$item['product_id']} | {$item['product_name']} | Qty: {$item['qty']} | Amount: ₹{$item['amount']}\n";
}

echo "\n\n";
echo str_repeat("=", 80) . "\n";
echo "ANALYSIS:\n";
echo str_repeat("=", 80) . "\n";

// Check for duplicate items in same order
$stmt = $pdo->query("
    SELECT order_id, product_id, COUNT(*) as count
    FROM orders_item
    GROUP BY order_id, product_id
    HAVING COUNT(*) > 1
");
$duplicates = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($duplicates) > 0) {
    echo "\n⚠️  DUPLICATE ITEMS FOUND:\n";
    foreach ($duplicates as $dup) {
        echo "  Order ID {$dup['order_id']}: Product ID {$dup['product_id']} appears {$dup['count']} times\n";
    }
} else {
    echo "\n✓ No duplicate items found\n";
}

// Check for orders with unexpected item counts
$stmt = $pdo->query("
    SELECT o.id, o.bill_no, COUNT(oi.id) as item_count
    FROM orders o
    LEFT JOIN orders_item oi ON o.id = oi.order_id
    GROUP BY o.id
    ORDER BY o.id DESC
    LIMIT 10
");
$orderCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "\n\nRecent Order Item Counts:\n";
foreach ($orderCounts as $order) {
    echo "  Order #{$order['bill_no']} (ID: {$order['id']}): {$order['item_count']} items\n";
}

echo "</pre>";
?>
