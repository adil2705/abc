<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/mailer.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['email']) || empty(trim($data['email']))) {
    http_response_code(400);
    echo json_encode(['error' => 'Email is required']);
    exit;
}

$email = trim($data['email']);

try {
    // Check if user exists
    $stmt = $pdo->prepare("SELECT id, name FROM buyers WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        // For security, do not reveal if email exists or not, just say email sent if it exists
        // But for UX, sometimes we want to say "Email not found". 
        // Let's stick to a generic success message or specific error if preferred by user.
        // Given the context, precise errors are often helpful for dev/small apps.
        http_response_code(404);
        echo json_encode(['error' => 'Email not found']);
        exit;
    }

    // Generate secure token
    $token = bin2hex(random_bytes(32));
    $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

    // Update user with token
    $updateStmt = $pdo->prepare("UPDATE buyers SET reset_token = ?, reset_expires = ? WHERE id = ?");
    $updateStmt->execute([$token, $expiry, $user['id']]);

    // Send Email
    $mailer = new Mailer();
    
    // Construct reset link - ensure no extra slash issues
    $baseUrl = trim(getenv('BASE_URL'), '/'); 
    // If BASE_URL points to backend, we might need FRONTEND_URL. 
    // Usually in this setup, they might be different.
    // Assuming BASE_URL is for API, and Frontend is on a different port or same host.
    // Let's deduce Frontend URL effectively or use a hardcoded one if env not set.
    // The previous code used BASE_URL/orders/invoice.php - which implies BASE_URL is backend or root.
    // The user's frontend is typically localhost:5173 or similar during dev, or same domain in prod.
    // I I will assume a standard structure or try to grab the referer if available, but env is safest.
    // I'll assume the frontend is served from the same domain root or use a placeholder.
    // Actually, I'll try to use a relative path if possible, or just a standard localhost URL for now if env missing.
    
    $resetLink = $baseUrl . "/reset-password?token=" . $token;
    // NOTE: If BASE_URL is the backend API url (e.g. localhost/mycode/backend/api), this link might need adjustment to point to frontend.
    // Typically frontend is `http://localhost:5173` in dev.
    // I will try to use http://localhost:5173 for now if likely in dev, or better, make it configurable.
    // Let's look at invoice link: getenv('BASE_URL') . "/orders/invoice.php"
    // I'll stick to a robust assumption or use the Referer header to guess the frontend origin.
    
    $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : 'http://localhost:5173';
    $resetLink = $origin . "/reset-password?token=" . $token;

    $subject = "Password Reset Request";
    $body = "
    <html>
    <body>
        <h2>Password Reset Request</h2>
        <p>Hi " . htmlspecialchars($user['name']) . ",</p>
        <p>We received a request to reset your password. Click the link below to reset it:</p>
        <p><a href='" . $resetLink . "'>Reset Password</a></p>
        <p>This link will expire in 1 hour.</p>
        <p>If you didn't request this, please ignore this email.</p>
    </body>
    </html>
    ";

    $mailer->send($email, $subject, $body, true);

    http_response_code(200);
    echo json_encode(['message' => 'Password reset link sent to your email']);

} catch (Exception $e) {
    error_log("Forgot Password Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to process request']);
}
?>
