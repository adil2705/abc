<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Authenticate buyer
$buyer = authenticateBuyer();

try {
    // Get buyer's orders
    $stmt = $pdo->prepare("
        SELECT o.*, 
        COUNT(oi.id) as item_count
        FROM orders o
        LEFT JOIN orders_item oi ON o.id = oi.order_id
        WHERE o.buyer_id = ?
        GROUP BY o.id
        ORDER BY o.date_time DESC
    ");
    $stmt->execute([$buyer['buyer_id']]);
    $orders = $stmt->fetchAll();
    
    // Get order items for each order
    foreach ($orders as &$order) {
        $stmt = $pdo->prepare("
            SELECT oi.*, p.name as product_name, p.image as product_image
            FROM orders_item oi
            LEFT JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
        ");
        $stmt->execute([$order['id']]);
        $order['items'] = $stmt->fetchAll();
    }
    
    http_response_code(200);
    echo json_encode(['orders' => $orders]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch orders']);
}
