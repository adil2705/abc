<?php
require_once __DIR__ . '/../../config/cors.php';
header('Content-Type: text/html');
require_once __DIR__ . '/../../config/database.php';

if (!isset($_GET['id'])) {
    die("Order ID required");
}

$id = intval($_GET['id']);

try {
    // Get Order
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->execute([$id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) die("Order not found");

    // Get Items
    $stmt = $pdo->prepare("SELECT oi.*, p.name as product_name FROM orders_item oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
    $stmt->execute([$id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get Company
    $stmt = $pdo->prepare("SELECT * FROM company WHERE id = 1");
    $stmt->execute();
    $company = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database error");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Invoice - <?php echo htmlspecialchars($order['bill_no']); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Arial', sans-serif; 
            padding: 20px; 
            background: #f5f5f5;
        }
        .invoice-box { 
            max-width: 800px; 
            margin: auto; 
            padding: 30px; 
            background: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, .15); 
        }
        .header { 
            display: flex; 
            justify-content: space-between; 
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #333;
        }
        .company-info h1 { 
            color: #333; 
            font-size: 28px; 
            margin-bottom: 10px;
        }
        .company-info p { 
            color: #666; 
            line-height: 1.6;
        }
        .invoice-info { 
            text-align: right; 
        }
        .invoice-info h2 { 
            color: #333; 
            font-size: 24px; 
            margin-bottom: 10px;
        }
        .invoice-info p { 
            color: #666; 
            line-height: 1.6;
        }
        .bill-to { 
            margin-bottom: 30px; 
            padding: 15px;
            background: #f9f9f9;
            border-left: 4px solid #333;
        }
        .bill-to strong { 
            display: block; 
            margin-bottom: 10px;
            color: #333;
            font-size: 16px;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 20px;
        }
        th { 
            padding: 12px; 
            text-align: left; 
            background: #333;
            color: white;
            font-weight: bold;
        }
        td { 
            padding: 12px; 
            border-bottom: 1px solid #ddd; 
        }
        tr:hover { 
            background: #f9f9f9; 
        }
        .totals { 
            margin-top: 20px; 
            text-align: right; 
        }
        .totals p { 
            margin: 8px 0; 
            font-size: 14px;
        }
        .totals h3 { 
            margin-top: 15px; 
            padding-top: 15px;
            border-top: 2px solid #333;
            color: #333;
            font-size: 20px;
        }
        .btn-container { 
            text-align: center; 
            margin-bottom: 20px; 
        }
        .print-btn { 
            background: #333; 
            color: #fff; 
            padding: 12px 30px; 
            text-decoration: none; 
            display: inline-block; 
            margin: 0 5px;
            cursor: pointer;
            border: none;
            font-size: 16px;
            border-radius: 4px;
        }
        .print-btn:hover { 
            background: #555; 
        }
        @media print { 
            body { background: white; padding: 0; }
            .invoice-box { box-shadow: none; padding: 0; }
            .btn-container { display: none; }
        }
        @page { 
            margin: 20mm; 
        }
    </style>
</head>
<body>
    <div class="invoice-box">
        <div class="btn-container">
            <button onclick="window.print()" class="print-btn">🖨️ Print Invoice</button>
            <button onclick="window.close()" class="print-btn" style="background: #666;">✕ Close</button>
        </div>
        
        <div class="header">
            <div class="company-info">
                <h1><?php echo htmlspecialchars($company['company_name'] ?? 'Sans Traaders'); ?></h1>
                <p><?php echo htmlspecialchars($company['address'] ?? ''); ?></p>
                <p>Phone: <?php echo htmlspecialchars($company['phone'] ?? ''); ?></p>
            </div>
            <div class="invoice-info">
                <h2>INVOICE</h2>
                <p><strong>Bill No:</strong> <?php echo htmlspecialchars($order['bill_no']); ?></p>
                <p><strong>Date:</strong> <?php echo date('d-m-Y', $order['date_time']); ?></p>
            </div>
        </div>

        <div class="bill-to">
            <strong>Bill To:</strong>
            <?php echo htmlspecialchars($order['customer_name']); ?><br>
            <?php echo htmlspecialchars($order['customer_address']); ?><br>
            <?php echo htmlspecialchars($order['customer_phone']); ?>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th style="text-align: center;">Qty</th>
                    <th style="text-align: right;">Rate</th>
                    <th style="text-align: right;">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                    <td style="text-align: center;"><?php echo $item['qty']; ?></td>
                    <td style="text-align: right;">₹<?php echo number_format($item['rate'], 2); ?></td>
                    <td style="text-align: right;">₹<?php echo number_format($item['amount'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="totals">
            <p>Gross Amount: ₹<?php echo number_format($order['gross_amount'], 2); ?></p>
            <p>Service Charge (<?php echo $order['service_charge_rate']; ?>%): ₹<?php echo number_format($order['service_charge'], 2); ?></p>
            <p>VAT (<?php echo $order['vat_charge_rate']; ?>%): ₹<?php echo number_format($order['vat_charge'], 2); ?></p>
            <h3>Net Amount: ₹<?php echo number_format($order['net_amount'], 2); ?></h3>
        </div>
    </div>
</body>
</html>
