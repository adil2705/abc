<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

// Check Auth (Admin Only) - assuming middleware or token check
// ...

$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
// Convert date to timestamp range
$startOfDay = strtotime($date . ' 00:00:00');
$endOfDay = strtotime($date . ' 23:59:59');

try {
    // Query to get product wise count for the day
    $stmt = $pdo->prepare("
        SELECT p.name as product_name, p.sku, SUM(oi.qty) as total_qty, SUM(oi.amount) as total_amount
        FROM orders_item oi
        JOIN orders o ON oi.order_id = o.id
        JOIN products p ON oi.product_id = p.id
        WHERE o.date_time BETWEEN ? AND ?
        AND o.order_status != 'cancelled'
        GROUP BY p.id
        ORDER BY total_qty DESC
    ");
    $stmt->execute([$startOfDay, $endOfDay]);
    $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['date' => $date, 'sales' => $sales]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
