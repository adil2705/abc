<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// Validate
if (!isset($data['username']) || !isset($data['password']) || !isset($data['email'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Check if username/email exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$data['username'], $data['email']]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Username or Email already exists']);
        exit;
    }

    // Insert User
    // Note: Use password_hash as seen in reset_admin.php
    $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (username, password, email, firstname, lastname, phone, gender) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $data['username'],
        $hashed_password,
        $data['email'],
        $data['firstname'] ?? '',
        $data['lastname'] ?? '',
        $data['phone'] ?? '',
        $data['gender'] ?? 1
    ]);
    $userId = $pdo->lastInsertId();

    // Assign Groups
    if (isset($data['group_id'])) {
        // Can be array or single id. Assuming single from 'Select Groups' dropdown or handle passed array.
        // If frontend sends array `groups: [1, 2]`.
        // Let's assume `groups` key is an array of IDs.
        $groups = is_array($data['groups'] ?? []) ? $data['groups'] : (($data['group_id'] ?? null) ? [$data['group_id']] : []);
        
        $stmtGroup = $pdo->prepare("INSERT INTO user_group (user_id, group_id) VALUES (?, ?)");
        foreach ($groups as $groupId) {
            $stmtGroup->execute([$userId, $groupId]);
        }
    }

    $pdo->commit();
    echo json_encode(['message' => 'User created successfully', 'id' => $userId]);

} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
