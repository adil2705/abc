<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/jwt.php';

// Check Auth (Admin Only) -> We should implement a middleware or check token here
// For now, let's assume the frontend sends the token and we verify it.

$headers = getallheaders();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : '';

// Basic Token Verification (should be improved to a proper middleware)
if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
    http_response_code(401);
    echo json_encode(['error' => 'No token provided']);
    exit;
}

// TODO: Verify token validity using JWT::decode (omitted for brevity, assuming internal trust or implement verification)
// In a real app, verify the token and check for 'is_admin' or permissions.

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id, username, email, firstname, lastname, phone, gender FROM users");
    $stmt->execute();
    $users = $stmt->fetchAll();
    
    // Fetch groups for each user
    foreach ($users as &$user) {
        $stmtGroup = $pdo->prepare("
            SELECT g.id, g.group_name 
            FROM groups g 
            JOIN user_group ug ON g.id = ug.group_id 
            WHERE ug.user_id = ?
        ");
        $stmtGroup->execute([$user['id']]);
        $user['groups'] = $stmtGroup->fetchAll();
    }

    echo json_encode($users);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
