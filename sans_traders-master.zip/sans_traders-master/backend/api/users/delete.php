<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'User ID required']);
    exit;
}

if ($data['id'] == 1) {
    http_response_code(403);
    echo json_encode(['error' => 'Cannot delete main admin user']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Delete relationships
    $pdo->prepare("DELETE FROM user_group WHERE user_id = ?")->execute([$data['id']]);
    // Optionally delete orders or other related data? For now, keep it simple or set user_id to null if supported.
    
    // Delete User
    $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$data['id']]);

    $pdo->commit();
    echo json_encode(['message' => 'User deleted successfully']);

} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
