<?php

class ImageUploader {
    private $uploadDir;
    private $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    private $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];
    private $maxFileSize = 5242880; // 5MB in bytes

    public function __construct($baseUploadDir = null) {
        // Default to project root media folder
        $this->uploadDir = $baseUploadDir ?? __DIR__ . '/../../media/uploads/';
    }

    /**
     * Upload an image file
     * 
     * @param array $file The $_FILES array element
     * @param string $category Category folder name (e.g., 'electronics', 'clothing')
     * @return array ['success' => bool, 'path' => string|null, 'error' => string|null]
     */
    public function upload($file, $category = 'other') {
        // Validate file was uploaded
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return ['success' => false, 'path' => null, 'error' => 'No file uploaded'];
        }

        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'path' => null, 'error' => $this->getUploadErrorMessage($file['error'])];
        }

        // Validate file size
        if ($file['size'] > $this->maxFileSize) {
            return ['success' => false, 'path' => null, 'error' => 'File size exceeds 5MB limit'];
        }

        // Validate MIME type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if (!in_array($mimeType, $this->allowedTypes)) {
            return ['success' => false, 'path' => null, 'error' => 'Invalid file type. Only JPG, JPEG, PNG, and WEBP are allowed'];
        }

        // Validate file extension
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, $this->allowedExtensions)) {
            return ['success' => false, 'path' => null, 'error' => 'Invalid file extension'];
        }

        // Sanitize category name
        $category = preg_replace('/[^a-z0-9_-]/i', '', strtolower($category));
        if (empty($category)) {
            $category = 'other';
        }

        // Create category directory if it doesn't exist
        $categoryDir = $this->uploadDir . $category . '/';
        if (!is_dir($categoryDir)) {
            if (!mkdir($categoryDir, 0755, true)) {
                return ['success' => false, 'path' => null, 'error' => 'Failed to create upload directory'];
            }
        }

        // Generate unique filename
        $uniqueName = $this->generateUniqueFilename($extension);
        $targetPath = $categoryDir . $uniqueName;

        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
            return ['success' => false, 'path' => null, 'error' => 'Failed to move uploaded file'];
        }

        // Return relative path for database storage
        $relativePath = '/media/uploads/' . $category . '/' . $uniqueName;
        
        return ['success' => true, 'path' => $relativePath, 'error' => null];
    }

    /**
     * Delete an image file
     * 
     * @param string $relativePath The relative path stored in database
     * @return bool Success status
     */
    public function delete($relativePath) {
        if (empty($relativePath) || $relativePath === 'not select image yet') {
            return true;
        }

        // Convert relative path to absolute (project root)
        $absolutePath = __DIR__ . '/../../' . ltrim($relativePath, '/');
        
        // Security check: ensure path is within upload directory
        $realPath = realpath($absolutePath);
        $realUploadDir = realpath($this->uploadDir);
        
        if ($realPath === false || strpos($realPath, $realUploadDir) !== 0) {
            return false;
        }

        // Delete file if it exists
        if (file_exists($absolutePath) && is_file($absolutePath)) {
            return unlink($absolutePath);
        }

        return true;
    }

    /**
     * Generate a unique filename
     * 
     * @param string $extension File extension
     * @return string Unique filename
     */
    private function generateUniqueFilename($extension) {
        $timestamp = time();
        $random = bin2hex(random_bytes(8));
        return $timestamp . '_' . $random . '.' . $extension;
    }

    /**
     * Get human-readable upload error message
     * 
     * @param int $errorCode PHP upload error code
     * @return string Error message
     */
    private function getUploadErrorMessage($errorCode) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'Upload stopped by extension',
        ];

        return $errors[$errorCode] ?? 'Unknown upload error';
    }
}
