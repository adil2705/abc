<?php
/**
 * Simple PDF Invoice Generator
 * Generates PDF invoices from HTML using wkhtmltopdf or similar
 * Falls back to HTML if PDF generation fails
 */

class PDFGenerator {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Generate invoice PDF for an order
     * @param int $orderId
     * @return array ['success' => bool, 'filename' => string, 'path' => string]
     */
    public function generateInvoice($orderId) {
        try {
            // Get order details
            $stmt = $this->pdo->prepare("SELECT * FROM orders WHERE id = ?");
            $stmt->execute([$orderId]);
            $order = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$order) {
                return ['success' => false, 'error' => 'Order not found'];
            }
            
            // Get order items
            $stmt = $this->pdo->prepare("
                SELECT oi.*, p.name as product_name, p.sku as product_sku 
                FROM orders_item oi 
                JOIN products p ON oi.product_id = p.id 
                WHERE oi.order_id = ?
            ");
            $stmt->execute([$orderId]);
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Get company details
            $stmt = $this->pdo->prepare("SELECT * FROM company WHERE id = 1");
            $stmt->execute();
            $company = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Generate filename with padded order ID
            $filename = 'INVOICE_' . str_pad($orderId, 6, '0', STR_PAD_LEFT) . '.pdf';
            
            // Generate HTML content
            $html = $this->generateInvoiceHTML($order, $items, $company);
            
            // Try to generate PDF using wkhtmltopdf if available
            $pdfPath = $this->convertHTMLToPDF($html, $filename);
            
            if ($pdfPath) {
                return [
                    'success' => true,
                    'filename' => $filename,
                    'path' => $pdfPath,
                    'html' => $html
                ];
            } else {
                // Fallback to HTML
                return [
                    'success' => true,
                    'filename' => str_replace('.pdf', '.html', $filename),
                    'html' => $html,
                    'isPDF' => false
                ];
            }
            
        } catch (Exception $e) {
            error_log("PDF Generation Error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    /**
     * Generate invoice HTML
     */
    private function generateInvoiceHTML($order, $items, $company) {
        ob_start();
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Invoice - <?php echo htmlspecialchars($order['bill_no']); ?></title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body { font-family: Arial, sans-serif; padding: 40px; background: white; color: #333; }
                .invoice-box { max-width: 800px; margin: auto; }
                .header { display: flex; justify-content: space-between; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 3px solid #333; }
                .company-info h1 { color: #333; font-size: 28px; margin-bottom: 10px; }
                .company-info p { color: #666; line-height: 1.6; font-size: 14px; }
                .invoice-info { text-align: right; }
                .invoice-info h2 { color: #333; font-size: 24px; margin-bottom: 10px; }
                .invoice-info p { color: #666; line-height: 1.6; font-size: 14px; }
                .bill-to { margin-bottom: 30px; padding: 15px; background: #f9f9f9; border-left: 4px solid #333; }
                .bill-to strong { display: block; margin-bottom: 10px; color: #333; font-size: 16px; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                th { padding: 12px; text-align: left; background: #333; color: white; font-weight: bold; }
                td { padding: 12px; border-bottom: 1px solid #ddd; }
                .totals { margin-top: 20px; text-align: right; }
                .totals p { margin: 8px 0; font-size: 14px; }
                .totals .total { margin-top: 15px; padding-top: 15px; border-top: 2px solid #333; color: #333; font-size: 20px; font-weight: bold; }
            </style>
        </head>
        <body>
            <div class="invoice-box">
                <div class="header">
                    <div class="company-info">
                        <h1><?php echo htmlspecialchars($company['company_name'] ?? 'SANS Traders'); ?></h1>
                        <p><?php echo htmlspecialchars($company['address'] ?? ''); ?></p>
                        <p>Phone: <?php echo htmlspecialchars($company['phone'] ?? ''); ?></p>
                    </div>
                    <div class="invoice-info">
                        <h2>INVOICE</h2>
                        <p><strong>Bill No:</strong> <?php echo htmlspecialchars($order['bill_no']); ?></p>
                        <p><strong>Date:</strong> <?php echo date('d-m-Y', $order['date_time']); ?></p>
                    </div>
                </div>

                <div class="bill-to">
                    <strong>Bill To:</strong>
                    <?php echo htmlspecialchars($order['customer_name']); ?><br>
                    <?php echo htmlspecialchars($order['customer_address']); ?><br>
                    <?php echo htmlspecialchars($order['customer_phone']); ?>
                </div>

                <table>
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th style="text-align: center;">Qty</th>
                            <th style="text-align: right;">Rate</th>
                            <th style="text-align: right;">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                            <td style="text-align: center;"><?php echo $item['qty']; ?></td>
                            <td style="text-align: right;">₹<?php echo number_format($item['rate'], 2); ?></td>
                            <td style="text-align: right;">₹<?php echo number_format($item['amount'], 2); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="totals">
                    <p>Gross Amount: ₹<?php echo number_format($order['gross_amount'], 2); ?></p>
                    <p>Service Charge (<?php echo $order['service_charge_rate']; ?>%): ₹<?php echo number_format($order['service_charge'], 2); ?></p>
                    <p>VAT (<?php echo $order['vat_charge_rate']; ?>%): ₹<?php echo number_format($order['vat_charge'], 2); ?></p>
                    <p class="total">Net Amount: ₹<?php echo number_format($order['net_amount'], 2); ?></p>
                </div>
            </div>
        </body>
        </html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Convert HTML to PDF using wkhtmltopdf or similar
     * Returns path to PDF file or false if conversion fails
     */
    private function convertHTMLToPDF($html, $filename) {
        // Check if wkhtmltopdf is available
        $wkhtmltopdf = $this->findWkhtmltopdf();
        
        if (!$wkhtmltopdf) {
            return false; // PDF generation not available
        }
        
        // Create temp directory if it doesn't exist
        $tempDir = __DIR__ . '/../temp';
        if (!is_dir($tempDir)) {
            mkdir($tempDir, 0755, true);
        }
        
        // Save HTML to temp file
        $htmlFile = $tempDir . '/' . uniqid() . '.html';
        $pdfFile = $tempDir . '/' . $filename;
        
        file_put_contents($htmlFile, $html);
        
        // Convert to PDF
        $command = escapeshellcmd($wkhtmltopdf) . ' ' . escapeshellarg($htmlFile) . ' ' . escapeshellarg($pdfFile) . ' 2>&1';
        exec($command, $output, $returnCode);
        
        // Clean up HTML file
        @unlink($htmlFile);
        
        if ($returnCode === 0 && file_exists($pdfFile)) {
            return $pdfFile;
        }
        
        return false;
    }
    
    /**
     * Find wkhtmltopdf executable
     */
    private function findWkhtmltopdf() {
        $possiblePaths = [
            'wkhtmltopdf', // If in PATH
            '/usr/bin/wkhtmltopdf',
            '/usr/local/bin/wkhtmltopdf',
            'C:\\Program Files\\wkhtmltopdf\\bin\\wkhtmltopdf.exe',
            'C:\\Program Files (x86)\\wkhtmltopdf\\bin\\wkhtmltopdf.exe'
        ];
        
        foreach ($possiblePaths as $path) {
            if (@exec("$path --version 2>&1", $output) !== false && !empty($output)) {
                return $path;
            }
        }
        
        return false;
    }
}
?>
