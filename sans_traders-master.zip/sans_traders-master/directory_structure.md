# Sans Traders - Project Structure

## 📂 Root Directory /
|-- `admin/`               # Admin Dashboard (React)
|-- `backend/`             # API & Server Logic (PHP)
|-- `frontend/`            # Customer Storefront (React)
|-- `media/`               # Public Uploads
|-- `final_structure.sql`  # Database Schema
|-- `README.md`            # Project Documentation

---

## 📂 Backend Structure (`backend/`)
The core API handling database, authentication, and logic.

```text
backend/
├── .env                  # configuration & credentials
├── config/               # Database connection & CORS
│   ├── database.php
│   └── cors.php
├── api/                  # API Endpoints
│   ├── auth/             # Login/Register endpoints
│   ├── products/         # Product CRUD & Uploads
│   ├── orders/           # Order processing & Invoices
│   ├── categories/       # Category management
│   └── admin/            # Admin specific stats/tools
├── utils/                # Helper classes
│   ├── ImageUploader.php
│   ├── jwt.php
│   └── pdf-generator.php
└── scripts/              # Maintenance scripts
```

---

## 📂 Frontend Structure (`frontend/`)
Customer-facing e-commerce application.

```text
frontend/
├── .env                  # API URL configuration
├── package.json          # Dependencies
├── vite.config.js        # Build configuration
└── src/
    ├── main.jsx          # Entry point
    ├── App.jsx           # Routes & Layout
    ├── components/       # Reusable UI components
    │   └── ProductCard.jsx
    ├── pages/            # Page Views
    │   ├── Home.jsx
    │   ├── Products.jsx
    │   ├── ProductDetail.jsx
    │   ├── Cart.jsx
    │   └── Checkout.jsx
    ├── context/          # State Management
    │   └── CartContext.jsx
    └── utils/
        └── api.js        # Axios instance
```

---

## 📂 Admin Structure (`admin/`)
Management dashboard for products, orders, and users.

```text
admin/
├── .env                  # API URL configuration
├── package.json          # Dependencies
├── vite.config.js        # Build configuration
└── src/
    ├── main.jsx          # Entry point
    ├── App.jsx           # Routes & Sidebar Layout
    ├── components/       # UI Components
    │   └── Sidebar.jsx
    ├── pages/            # Admin Views
    │   ├── Dashboard.jsx
    │   ├── Products/
    │   │   ├── ManageProducts.jsx
    │   │   └── AddProduct.jsx
    │   └── Orders/
    │       └── ManageOrders.jsx
    └── utils/
        └── api.js        # Axios instance
```

---

## 📂 Media Structure (`media/`)
Publicly accessible static assets.

```text
media/
├── .htaccess             # Security rules (Allow images, Deny PHP)
└── uploads/              # Dynamic uploads
    ├── clothing/
    ├── electronics/
    ├── face-wash/
    ├── food/
    └── other/
```
