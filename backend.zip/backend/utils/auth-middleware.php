<?php
require_once __DIR__ . '/jwt.php';

function authenticateBuyer() {
    $headers = getallheaders();
    
    if (!isset($headers['Authorization'])) {
        http_response_code(401);
        echo json_encode(['error' => 'No token provided']);
        exit;
    }
    
    $authHeader = $headers['Authorization'];
    $token = str_replace('Bearer ', '', $authHeader);
    
    $decoded = JWT::decode($token);
    
    if (!$decoded || !isset($decoded['buyer_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid token']);
        exit;
    }
    
    return $decoded;
}

function authenticateAdmin() {
    $headers = getallheaders();
    
    if (!isset($headers['Authorization'])) {
        http_response_code(401);
        echo json_encode(['error' => 'No token provided']);
        exit;
    }
    
    $authHeader = $headers['Authorization'];
    $token = str_replace('Bearer ', '', $authHeader);
    
    $decoded = JWT::decode($token);
    
    if (!$decoded || !isset($decoded['user_id']) || !isset($decoded['is_admin'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid admin token']);
        exit;
    }
    
    return $decoded;
}
