<?php
require_once __DIR__ . '/../config/env_loader.php';

class WhatsAppService {
    private $apiUrl;
    private $apiKey;
    private $adminNumber;

    public function __construct() {
        $this->apiUrl = getenv('WHATSAPP_API_URL');
        $this->apiKey = getenv('WHATSAPP_API_KEY');
        $this->adminNumber = getenv('ADMIN_WHATSAPP_NUMBER');
    }

    public function sendOrderNotification($orderData) {
        if (empty($this->apiUrl) || empty($this->adminNumber)) {
            error_log("WhatsApp Error: Configuration missing");
            return false;
        }

        $message = $this->formatMessage($orderData);
        return $this->sendMessage($this->adminNumber, $message);
    }

    private function formatMessage($data) {
        $orderId = $data['bill_no'];
        $customerName = $data['customer_name'] ?? 'Guest';
        $phone = $data['customer_phone'] ?? '';
        $address = $data['delivery_address'] ?? 'N/A';
        $netAmount = isset($data['net_amount']) ? $data['net_amount'] : 0;
        $total = number_format(floatval($netAmount), 2);
        
        $msg = "*New Order Received* 📦\n\n";
        $msg .= "*Order ID:* $orderId\n";
        $msg .= "*Customer:* $customerName\n";
        $msg .= "*Phone:* $phone\n";
        $msg .= "*Total:* ₹$total\n\n";
        
        $msg .= "*Items:* \n";
        if (isset($data['items']) && is_array($data['items'])) {
            foreach ($data['items'] as $item) {
                $prodName = $item['product_name'] ?? 'Product';
                $qty = $item['qty'] ?? 1;
                $msg .= "- " . $prodName . " x " . $qty . "\n";
            }
        }
        
        $msg .= "\n*Address:* $address";
        
        return $msg;
    }

    private function sendMessage($to, $message) {
        // Implementation for CallMeBot / Generic URL
        // Replaces placholders [phone], [text], [apikey]
        
        $encodedMessage = urlencode($message);
        $url = $this->apiUrl;

        // Replace placeholders if they exist in the URL string
        if (strpos($url, '[phone]') !== false) {
            $url = str_replace('[phone]', $to, $url);
            $url = str_replace('[text]', $encodedMessage, $url);
            $url = str_replace('[apikey]', $this->apiKey, $url);
        } else {
            // Fallback: Append as query params if no placeholders found
            $connector = strpos($url, '?') !== false ? '&' : '?';
            $url .= "{$connector}phone={$to}&text={$encodedMessage}&apikey={$this->apiKey}";
        }

        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            
            if (curl_errno($ch)) {
                error_log("WhatsApp Curl Error: " . curl_error($ch));
                curl_close($ch);
                return false;
            }
            
            curl_close($ch);
            
            if ($httpCode >= 400) {
                error_log("WhatsApp API Error ($httpCode): $response");
                // CallMeBot might return 200 even on error text, so we rely on HTTP code usually.
                return false;
            }
            
            error_log("WhatsApp Notification Sent: HTTP $httpCode");
            return true;

        } catch (Exception $e) {
            error_log("WhatsApp Exception: " . $e->getMessage());
            return false;
        }
    }
}
?>
