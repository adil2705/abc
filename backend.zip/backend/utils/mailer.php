<?php
require_once __DIR__ . '/../config/env_loader.php';

class Mailer {
    private $host;
    private $port;
    private $username;
    private $password;
    private $fromEmail;
    private $fromName;

    public function __construct() {
        $this->host = getenv('SMTP_HOST');
        $this->port = getenv('SMTP_PORT');
        $this->username = getenv('SMTP_EMAIL');
        $this->password = getenv('SMTP_PASSWORD');
        $this->fromEmail = getenv('SMTP_FROM_EMAIL');
        $this->fromName = getenv('SMTP_FROM_NAME');
    }

    public function send($to, $subject, $body, $isHtml = true) {
        // Validate SMTP configuration
        if (empty($this->host) || empty($this->username) || empty($this->password)) {
            error_log("Mailer Error: SMTP credentials not configured in .env");
            return false;
        }

        try {
            $socket = @fsockopen($this->host, $this->port, $errno, $errstr, 30);
            if (!$socket) {
                error_log("Mailer Error: Could not connect to SMTP host {$this->host}:{$this->port} - $errstr ($errno)");
                return false;
            }

            $response = $this->readResponse($socket);
            if (substr($response, 0, 3) != '220') {
                error_log("Mailer Error: Invalid SMTP greeting: $response");
                fclose($socket);
                return false;
            }
            
            $this->sendCommand($socket, "EHLO " . gethostname());
            $this->sendCommand($socket, "STARTTLS");
            
            if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                error_log("Mailer Error: Failed to enable TLS encryption");
                fclose($socket);
                return false;
            }
            
            $this->sendCommand($socket, "EHLO " . gethostname());
            $this->sendCommand($socket, "AUTH LOGIN");
            $this->sendCommand($socket, base64_encode($this->username));
            
            $authResponse = $this->sendCommand($socket, base64_encode($this->password));
            if (substr($authResponse, 0, 3) != '235') {
                error_log("Mailer Error: SMTP authentication failed: $authResponse");
                fclose($socket);
                return false;
            }
            
            $this->sendCommand($socket, "MAIL FROM: <" . $this->fromEmail . ">");
            $this->sendCommand($socket, "RCPT TO: <" . $to . ">");
            $this->sendCommand($socket, "DATA");
            
            $headers = "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: " . ($isHtml ? "text/html" : "text/plain") . "; charset=UTF-8\r\n";
            $headers .= "From: " . $this->fromName . " <" . $this->fromEmail . ">\r\n";
            $headers .= "To: " . $to . "\r\n";
            $headers .= "Subject: " . $subject . "\r\n";
            
            $message = $headers . "\r\n" . $body . "\r\n.";
            $this->sendCommand($socket, $message);
            $this->sendCommand($socket, "QUIT");
            fclose($socket);
            
            error_log("Mailer: Email sent successfully to $to");
            return true;
        } catch (Exception $e) {
            error_log("Mailer Error: " . $e->getMessage());
            return false;
        }
    }

    private function sendCommand($socket, $command) {
        fwrite($socket, $command . "\r\n");
        return $this->readResponse($socket);
    }

    private function readResponse($socket) {
        $response = "";
        while ($str = fgets($socket, 515)) {
            $response .= $str;
            if (substr($str, 3, 1) == " ") break;
        }
        return $response;
    }
}
?>
