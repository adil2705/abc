<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Authenticate admin
authenticateAdmin();

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Product ID is required']);
    exit;
}

$id = intval($data['id']);

try {
    // Check if product exists
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    if (!$product) {
        http_response_code(404);
        echo json_encode(['error' => 'Product not found']);
        exit;
    }
    
    // Check if product has orders
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders_item WHERE product_id = ?");
    $stmt->execute([$id]);
    $orderCount = $stmt->fetchColumn();
    
    if ($orderCount > 0) {
        // Soft delete - set availability to 0
        $stmt = $pdo->prepare("UPDATE products SET availability = 0 WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['message' => 'Product deactivated (has existing orders)']);
    } else {
        // Hard delete
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['message' => 'Product deleted successfully']);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to delete product']);
}
?>
