<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Authenticate admin
authenticateAdmin();

$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 20;
$offset = ($page - 1) * $limit;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? intval($_GET['category']) : 0;
$brand = isset($_GET['brand']) ? intval($_GET['brand']) : 0;

try {
    // Build query
    $where = ['p.availability = 1'];
    $params = [];
    
    if ($search) {
        $where[] = '(p.name LIKE ? OR p.sku LIKE ?)';
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    if ($category > 0) {
        $where[] = 'p.category_id = ?';
        $params[] = $category;
    }
    
    if ($brand > 0) {
        $where[] = 'p.brand_id = ?';
        $params[] = $brand;
    }
    
    $whereClause = implode(' AND ', $where);
    
    // Get total count
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM products p WHERE $whereClause");
    $stmt->execute($params);
    $total = $stmt->fetchColumn();
    
    // Get products with joins - Note: brand_id and category_id might be JSON strings like ["1"] or plain strings/null
    $query = "
        SELECT 
            p.*,
            b.name as brand_name,
            c.name as category_name,
            s.name as store_name
        FROM products p
        LEFT JOIN brands b ON (p.brand_id = b.id OR p.brand_id LIKE CONCAT('%\"', b.id, '\"%'))
        LEFT JOIN categories c ON (p.category_id = c.id OR p.category_id LIKE CONCAT('%\"', c.id, '\"%'))
        LEFT JOIN stores s ON p.store_id = s.id
        WHERE $whereClause
        ORDER BY p.id DESC
        LIMIT ? OFFSET ?
    ";
    
    $stmt = $pdo->prepare($query);
    $i = 1;
    foreach ($params as $val) {
        $stmt->bindValue($i++, $val);
    }
    // Bind limit and offset as integers
    $stmt->bindValue($i++, $limit, PDO::PARAM_INT);
    $stmt->bindValue($i++, $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'products' => $products,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'pages' => ceil($total / $limit)
        ]
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch products: ' . $e->getMessage()]);
}
?>
