<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get query parameters
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = isset($_GET['limit']) ? min(50, max(1, intval($_GET['limit']))) : 20;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? intval($_GET['category']) : 0;
$brand = isset($_GET['brand']) ? intval($_GET['brand']) : 0;

$offset = ($page - 1) * $limit;

try {
    // Build query
    $sql = "SELECT p.*, 
            GROUP_CONCAT(DISTINCT b.name) as brand_name,
            GROUP_CONCAT(DISTINCT c.name) as category_name
            FROM products p
            LEFT JOIN brands b ON FIND_IN_SET(b.id, REPLACE(REPLACE(p.brand_id, '[', ''), ']', ''))
            LEFT JOIN categories c ON FIND_IN_SET(c.id, REPLACE(REPLACE(p.category_id, '[', ''), ']', ''))
            WHERE p.availability = 1";
    
    $params = [];
    
    // Add search filter
    if ($search) {
        $sql .= " AND (p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ? OR b.name LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    // Add category filter
    if ($category > 0) {
        $sql .= " AND FIND_IN_SET(?, REPLACE(REPLACE(p.category_id, '[', ''), ']', ''))";
        $params[] = $category;
    }
    
    // Add brand filter
    if ($brand > 0) {
        $sql .= " AND FIND_IN_SET(?, REPLACE(REPLACE(p.brand_id, '[', ''), ']', ''))";
        $params[] = $brand;
    }
    
    $sql .= " GROUP BY p.id ORDER BY p.id DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
    
    // Get total count
    $countSql = "SELECT COUNT(DISTINCT p.id) as total FROM products p WHERE p.availability = 1";
    $countParams = [];
    
    if ($search) {
        $countSql .= " AND (p.name LIKE ? OR p.description LIKE ? OR p.sku LIKE ? OR EXISTS (SELECT 1 FROM brands b WHERE FIND_IN_SET(b.id, REPLACE(REPLACE(p.brand_id, '[', ''), ']', '')) AND b.name LIKE ?))";
        $countParams[] = $searchTerm;
        $countParams[] = $searchTerm;
        $countParams[] = $searchTerm;
        $countParams[] = $searchTerm;
    }
    
    if ($category > 0) {
        $countSql .= " AND FIND_IN_SET(?, REPLACE(REPLACE(p.category_id, '[', ''), ']', ''))";
        $countParams[] = $category;
    }
    
    if ($brand > 0) {
        $countSql .= " AND FIND_IN_SET(?, REPLACE(REPLACE(p.brand_id, '[', ''), ']', ''))";
        $countParams[] = $brand;
    }
    
    $countStmt = $pdo->prepare($countSql);
    $countStmt->execute($countParams);
    $total = $countStmt->fetch()['total'];
    
    http_response_code(200);
    echo json_encode([
        'products' => $products,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'total' => intval($total),
            'pages' => ceil($total / $limit)
        ]
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch products']);
}
