<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Authenticate buyer
$buyer = authenticateBuyer();

$data = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($data['items']) || !is_array($data['items']) || empty($data['items'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Order items are required']);
    exit;
}

if (!isset($data['delivery_address']) || empty(trim($data['delivery_address']))) {
    http_response_code(400);
    echo json_encode(['error' => 'Delivery address is required']);
    exit;
}

$items = $data['items'];
$deliveryAddress = trim($data['delivery_address']);
$orderNotes = isset($data['order_notes']) ? trim($data['order_notes']) : '';

try {
    $pdo->beginTransaction();
    
    // Get buyer details
    $stmt = $pdo->prepare("SELECT * FROM buyers WHERE id = ?");
    $stmt->execute([$buyer['buyer_id']]);
    $buyerData = $stmt->fetch();
    
    // Calculate order totals
    $grossAmount = 0;
    $orderItems = [];
    
    foreach ($items as $item) {
        if (!isset($item['product_id']) || !isset($item['qty'])) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['error' => 'Invalid item data']);
            exit;
        }
        
        $productId = intval($item['product_id']);
        $qty = intval($item['qty']);
        
        if ($qty <= 0) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['error' => 'Invalid quantity']);
            exit;
        }
        
        // Get product details
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND availability = 1");
        $stmt->execute([$productId]);
        $product = $stmt->fetch();
        
        if (!$product) {
            $pdo->rollBack();
            http_response_code(404);
            echo json_encode(['error' => 'Product not found: ' . $productId]);
            exit;
        }
        
        $rate = floatval($product['price']);
        
        // Calculate discounted rate if applicable
        if (!empty($product['discount'])) {
             $discountPercent = floatval(str_replace('%', '', $product['discount']));
             if ($discountPercent > 0) {
                 $rate = $rate * (1 - $discountPercent / 100);
             }
        }
        
        $amount = $rate * $qty;
        $grossAmount += $amount;
        
        $orderItems[] = [
            'product_id' => $productId,
            'product_name' => $product['name'],
            'qty' => $qty,
            'rate' => $rate,
            'amount' => $amount
        ];
    }
    
    // Get company settings for charges
    $stmt = $pdo->prepare("SELECT * FROM company WHERE id = 1");
    $stmt->execute();
    $company = $stmt->fetch();
    
    $serviceChargeRate = floatval($company['service_charge_value']);
    $vatChargeRate = floatval($company['vat_charge_value']);
    
    $serviceCharge = ($grossAmount * $serviceChargeRate) / 100;
    $vatCharge = ($grossAmount * $vatChargeRate) / 100;
    $netAmount = $grossAmount + $serviceCharge + $vatCharge;
    
    // Generate bill number
    $billNo = 'BILPR-' . strtoupper(substr(md5(uniqid()), 0, 4));
    
    // Insert order
    $stmt = $pdo->prepare("
        INSERT INTO orders (
            bill_no, customer_name, customer_address, customer_phone, 
            date_time, gross_amount, service_charge_rate, service_charge, 
            vat_charge_rate, vat_charge, net_amount, discount, paid_status, 
            user_id, buyer_id, order_status, delivery_address, order_notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $billNo,
        $buyerData['name'],
        $buyerData['address'],
        $buyerData['phone'],
        time(),
        $grossAmount,
        $serviceChargeRate,
        $serviceCharge,
        $vatChargeRate,
        $vatCharge,
        $netAmount,
        0,
        0, // paid_status: 0 = unpaid
        1, // default admin user_id
        $buyer['buyer_id'],
        'pending',
        $deliveryAddress,
        $orderNotes
    ]);
    
    $orderId = $pdo->lastInsertId();
    
    // Insert order items (no stock updates)
    foreach ($orderItems as $orderItem) {
        $stmt = $pdo->prepare("
            INSERT INTO orders_item (order_id, product_id, qty, rate, amount) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $orderId,
            $orderItem['product_id'],
            $orderItem['qty'],
            $orderItem['rate'],
            $orderItem['amount']
        ]);
    }
    
    $pdo->commit();

    // Send Emails
    try {
        require_once __DIR__ . '/../../utils/mailer.php';
        $mailer = new Mailer();

        // Build product list HTML
        $productListHtml = '<table style="width: 100%; border-collapse: collapse; margin: 20px 0;">';
        $productListHtml .= '<thead><tr style="background: #f5f5f5;">';
        $productListHtml .= '<th style="padding: 10px; text-align: left; border-bottom: 2px solid #ddd;">Product</th>';
        $productListHtml .= '<th style="padding: 10px; text-align: center; border-bottom: 2px solid #ddd;">Qty</th>';
        $productListHtml .= '<th style="padding: 10px; text-align: right; border-bottom: 2px solid #ddd;">Rate</th>';
        $productListHtml .= '<th style="padding: 10px; text-align: right; border-bottom: 2px solid #ddd;">Amount</th>';
        $productListHtml .= '</tr></thead><tbody>';
        
        foreach ($orderItems as $item) {
            $productListHtml .= '<tr>';
            $productListHtml .= '<td style="padding: 10px; border-bottom: 1px solid #eee;">' . htmlspecialchars($item['product_name'] ?? 'Product') . '</td>';
            $productListHtml .= '<td style="padding: 10px; text-align: center; border-bottom: 1px solid #eee;">' . $item['qty'] . '</td>';
            $productListHtml .= '<td style="padding: 10px; text-align: right; border-bottom: 1px solid #eee;">₹' . number_format($item['rate'], 2) . '</td>';
            $productListHtml .= '<td style="padding: 10px; text-align: right; border-bottom: 1px solid #eee;">₹' . number_format($item['amount'], 2) . '</td>';
            $productListHtml .= '</tr>';
        }
        $productListHtml .= '</tbody></table>';

        // Invoice link
        $invoiceLink = getenv('BASE_URL') . "/orders/invoice.php?id=" . $orderId;
        
        // 1. Email to Buyer
        $buyerSubject = "Order Confirmation - " . $billNo;
        $buyerBody = '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #333; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #fff; }
                .footer { background: #f5f5f5; padding: 15px; text-align: center; font-size: 12px; color: #666; }
                .totals { margin-top: 20px; text-align: right; }
                .totals p { margin: 5px 0; }
                .total-amount { font-size: 18px; font-weight: bold; color: #333; margin-top: 10px; padding-top: 10px; border-top: 2px solid #333; }
                .btn { display: inline-block; padding: 12px 24px; background: #333; color: white; text-decoration: none; border-radius: 4px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Thank You for Your Order!</h1>
                </div>
                <div class="content">
                    <p>Hi ' . htmlspecialchars($buyerData['name']) . ',</p>
                    <p>Your order <strong>' . $billNo . '</strong> has been placed successfully.</p>
                    
                    <h3>Order Details:</h3>
                    ' . $productListHtml . '
                    
                    <div class="totals">
                        <p>Gross Amount: ₹' . number_format($grossAmount, 2) . '</p>
                        <p>Service Charge (' . $serviceChargeRate . '%): ₹' . number_format($serviceCharge, 2) . '</p>
                        <p>VAT (' . $vatChargeRate . '%): ₹' . number_format($vatCharge, 2) . '</p>
                        <p class="total-amount">Total Amount: ₹' . number_format($netAmount, 2) . '</p>
                    </div>
                    
                    <p style="margin-top: 30px;">
                        <strong>Shipping Details:</strong><br>
                        ' . htmlspecialchars($shippingName ?? $buyerData['name']) . '<br>
                        ' . htmlspecialchars($shippingPhone ?? $buyerData['phone']) . '<br>
                        ' . nl2br(htmlspecialchars($deliveryAddress)) . '
                    </p>
                    

                    
                    <p>We will process your order shortly and keep you updated on the delivery status.</p>
                </div>
                <div class="footer">
                    <p>Best Regards,<br><strong>SANS Traders</strong></p>
                    <p>This is an automated email. Please do not reply to this message.</p>
                </div>
            </div>
        </body>
        </html>';

        $mailer->send($buyerData['email'], $buyerSubject, $buyerBody, true);

        // 2. Email to Admin
        $adminEmail = getenv('ADMIN_EMAIL') ?: getenv('SMTP_EMAIL');
        $adminSubject = "New Order Received - " . $billNo;
        $adminBody = '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #d32f2f; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background: #fff; }
                .info-box { background: #f5f5f5; padding: 15px; margin: 15px 0; border-left: 4px solid #d32f2f; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🔔 New Order Alert</h1>
                </div>
                <div class="content">
                    <p>A new order has been received!</p>
                    
                    <div class="info-box">
                        <p><strong>Order ID:</strong> ' . $billNo . '</p>
                        <p><strong>Customer:</strong> ' . htmlspecialchars($buyerData['name']) . '</p>
                        <p><strong>Email:</strong> ' . htmlspecialchars($buyerData['email']) . '</p>
                        <p><strong>Phone:</strong> ' . htmlspecialchars($buyerData['phone']) . '</p>
                        <p><strong>Order Total:</strong> ₹' . number_format($netAmount, 2) . '</p>
                    </div>
                    
                    <h3>Order Items:</h3>
                    ' . $productListHtml . '
                    
                    <div class="info-box">
                        <p><strong>Shipping To:</strong><br>
                        ' . htmlspecialchars($shippingName ?? $buyerData['name']) . '<br>
                        ' . htmlspecialchars($shippingPhone ?? $buyerData['phone']) . '<br>
                        ' . nl2br(htmlspecialchars($deliveryAddress)) . '</p>
                    </div>
                    
                    ' . ($orderNotes ? '<p><strong>Order Notes:</strong><br>' . nl2br(htmlspecialchars($orderNotes)) . '</p>' : '') . '
                    
                    <p style="margin-top: 20px;">Please process this order from the admin panel.</p>
                </div>
            </div>
        </body>
        </html>';

        $mailer->send($adminEmail, $adminSubject, $adminBody, true);
    } catch (Exception $e) {
        // Log email error but don't fail the order creation
        error_log("Failed to send order emails: " . $e->getMessage());
    }

    // Send WhatsApp Notification
    try {
        require_once __DIR__ . '/../../utils/whatsapp.php';
        $whatsapp = new WhatsAppService();
        $notificationData = [
            'bill_no' => $billNo,
            'customer_name' => $buyerData['name'],
            'customer_phone' => $buyerData['phone'],
            'delivery_address' => $deliveryAddress,
            'net_amount' => $netAmount,
            'items' => $orderItems
        ];
        $whatsapp->sendOrderNotification($notificationData);
    } catch (Exception $e) {
        error_log("Failed to send WhatsApp notification: " . $e->getMessage());
    }
    
    
    http_response_code(201);
    echo json_encode([
        'message' => 'Order placed successfully',
        'order' => [
            'id' => $orderId,
            'bill_no' => $billNo,
            'gross_amount' => $grossAmount,
            'net_amount' => $netAmount,
            'order_status' => 'pending',
            'invoice_url' => $invoiceLink
        ]
    ]);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Failed to create order']);
}
