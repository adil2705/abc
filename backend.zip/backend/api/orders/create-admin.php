<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/auth-middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Authenticate admin
// Authenticate admin and get user data
$decoded = authenticateAdmin();
$userId = $decoded['user_id'];

$data = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($data['items']) || !is_array($data['items']) || empty($data['items'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Order items are required']);
    exit;
}

if (!isset($data['customer_name']) || empty(trim($data['customer_name']))) {
    http_response_code(400);
    echo json_encode(['error' => 'Customer name is required']);
    exit;
}

if (!isset($data['customer_phone']) || empty(trim($data['customer_phone']))) {
    http_response_code(400);
    echo json_encode(['error' => 'Customer phone is required']);
    exit;
}

if (!isset($data['customer_address']) || empty(trim($data['customer_address']))) {
    http_response_code(400);
    echo json_encode(['error' => 'Customer address is required']);
    exit;
}

$items = $data['items'];
$customerName = trim($data['customer_name']);
$customerPhone = trim($data['customer_phone']);
$customerAddress = trim($data['customer_address']);
$customerEmail = isset($data['customer_email']) ? trim($data['customer_email']) : '';
$deliveryAddress = isset($data['delivery_address']) && !empty(trim($data['delivery_address'])) 
    ? trim($data['delivery_address']) 
    : $customerAddress;
$orderNotes = isset($data['order_notes']) ? trim($data['order_notes']) : '';
// Global discount is deprecated in favor of per-item discount, but keeping valid for compatibility if needed.
// Ideally, set global discount to 0 if per-item is used.
$globalDiscount = isset($data['discount']) ? floatval($data['discount']) : 0;

try {
    $pdo->beginTransaction();
    
    // Calculate order totals
    $grossAmount = 0;
    $orderItems = [];
    $totalItemDiscount = 0;
    
    foreach ($items as $item) {
        if (!isset($item['product_id']) || !isset($item['qty'])) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['error' => 'Invalid item data']);
            exit;
        }
        
        $productId = intval($item['product_id']);
        $qty = intval($item['qty']);
        $cashDiscountPercentage = isset($item['cash_discount_percentage']) ? floatval($item['cash_discount_percentage']) : 0;
        
        if ($qty <= 0) {
            $pdo->rollBack();
            http_response_code(400);
            echo json_encode(['error' => 'Invalid quantity']);
            exit;
        }
        
        // Get product details
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ? AND availability = 1");
        $stmt->execute([$productId]);
        $product = $stmt->fetch();
        
        if (!$product) {
            $pdo->rollBack();
            http_response_code(404);
            echo json_encode(['error' => 'Product not found: ' . $productId]);
            exit;
        }
        
        // 1. Original Rate (Price from DB)
        $originalRate = floatval($product['price']);
        
        // 2. Company Discount (from product definition)
        // Can be percentage ("10%") or flat amount ("10")? 
        // Logic usually implies percentage if it has %, otherwise flat.
        // Let's handle both.
        $companyDiscountRaw = $product['discount']; // e.g. "10", "10%", or ""
        $companyDiscountValue = 0;
        
        if (strpos($companyDiscountRaw, '%') !== false) {
            $percent = floatval(str_replace('%', '', $companyDiscountRaw));
            $companyDiscountValue = ($originalRate * $percent) / 100;
        } else {
            $companyDiscountValue = floatval($companyDiscountRaw);
        }
        
        // 3. Cash Discount (Percentage applied on Original Price)
        $cashDiscountValue = ($originalRate * $cashDiscountPercentage) / 100;
        
        // Final Rate Calculation
        // Rate = Original - CompanyDisc - CashDisc
        $finalRate = $originalRate - $companyDiscountValue - $cashDiscountValue;
        
        if ($finalRate < 0) $finalRate = 0;
        
        // Total Amount for this line item
        $amount = $finalRate * $qty;
        
        $grossAmount += $amount;
        
        $orderItems[] = [
            'product_id' => $productId,
            'qty' => $qty,
            'rate' => $finalRate, // The rate stored in 'rate' column is the final selling price
            'amount' => $amount,
            
            // Extra columns for tracking
            'original_rate' => $originalRate,
            'company_discount' => $companyDiscountValue, // storing value per unit
            'cash_discount_percentage' => $cashDiscountPercentage,
            'discount' => ($companyDiscountValue + $cashDiscountValue) * $qty, // Total discount for this line (for legacy/display)
            
            'product_name' => $product['name'] 
        ];
    }
    
    // Get company settings for charges
    $stmt = $pdo->prepare("SELECT * FROM company WHERE id = 1");
    $stmt->execute();
    $company = $stmt->fetch();
    
    $serviceChargeRate = floatval($company['service_charge_value']);
    $vatChargeRate = floatval($company['vat_charge_value']);
    
    $serviceCharge = ($grossAmount * $serviceChargeRate) / 100;
    $vatCharge = ($grossAmount * $vatChargeRate) / 100;
    
    $netAmount = $grossAmount + $serviceCharge + $vatCharge - $globalDiscount;
    
    if ($netAmount < 0) $netAmount = 0;

    // Generate bill number
    $billNo = 'BILPR-' . strtoupper(substr(md5(uniqid()), 0, 4));
    
    // Insert order
    $stmt = $pdo->prepare("
        INSERT INTO orders (
            bill_no, customer_name, customer_address, customer_phone, 
            date_time, gross_amount, service_charge_rate, service_charge, 
            vat_charge_rate, vat_charge, net_amount, discount, paid_status, 
            user_id, buyer_id, order_status, delivery_address, order_notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $billNo,
        $customerName,
        $customerAddress,
        $customerPhone,
        time(),
        $grossAmount,
        $serviceChargeRate,
        $serviceCharge,
        $vatChargeRate,
        $vatCharge,
        $netAmount,
        $globalDiscount,
        0, // paid_status: 0 = unpaid
        $userId, 
        null, 
        'pending',
        $deliveryAddress,
        $orderNotes
    ]);
    
    $orderId = $pdo->lastInsertId();
    
    // Insert order items
    foreach ($orderItems as $orderItem) {
        $stmt = $pdo->prepare("
            INSERT INTO orders_item (
                order_id, product_id, qty, rate, amount, 
                discount, original_rate, company_discount, cash_discount_percentage
            ) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $orderId,
            $orderItem['product_id'],
            $orderItem['qty'],
            $orderItem['rate'],
            $orderItem['amount'],
            $orderItem['discount'],
            $orderItem['original_rate'],
            $orderItem['company_discount'],
            $orderItem['cash_discount_percentage']
        ]);
    }
    
    $pdo->commit();

    // Send WhatsApp Notification
    try {
        require_once __DIR__ . '/../../utils/whatsapp.php';
        $whatsapp = new WhatsAppService();
        $notificationData = [
            'bill_no' => $billNo,
            'customer_name' => $customerName,
            'customer_phone' => $customerPhone,
            'delivery_address' => $deliveryAddress,
            'net_amount' => $netAmount,
            'items' => $orderItems
        ];
        $whatsapp->sendOrderNotification($notificationData);
    } catch (Exception $e) {
        error_log("Failed to send WhatsApp notification: " . $e->getMessage());
    }

    // Send Email if customer email provided
    if ($customerEmail) {
        try {
            require_once __DIR__ . '/../../utils/mailer.php';
            $mailer = new Mailer();

            $invoiceLink = getenv('BASE_URL') . "/orders/invoice.php?id=" . $orderId;
            
            $emailBody = "<h1>Thank you for your purchase!</h1>";
            $emailBody .= "<p>Hi " . htmlspecialchars($customerName) . ",</p>";
            $emailBody .= "<p>Your order <strong>" . $billNo . "</strong> has been placed successfully.</p>";
            $emailBody .= "<p><strong>Order Total:</strong> ₹" . number_format($netAmount, 2) . "</p>";

            $emailBody .= "<br><p>Best Regards,<br>SANS Traders</p>";

            $mailer->send($customerEmail, "Order Confirmation - " . $billNo, $emailBody, true);
        } catch (Exception $e) {
            error_log("Failed to send customer email: " . $e->getMessage());
        }
    }
    
    $invoiceLink = getenv('BASE_URL') . "/orders/invoice.php?id=" . $orderId;
    
    http_response_code(201);
    echo json_encode([
        'message' => 'Order created successfully',
        'order' => [
            'id' => $orderId,
            'bill_no' => $billNo,
            'gross_amount' => $grossAmount,
            'net_amount' => $netAmount,
            'order_status' => 'pending',
            'invoice_url' => $invoiceLink
        ]
    ]);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Failed to create order']);
}
?>
