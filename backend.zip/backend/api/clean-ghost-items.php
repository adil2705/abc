<?php
require_once __DIR__ . '/../config/database.php';

echo "<h2>Cleaning Ghost Items</h2>";
echo "<pre>";

try {
    // Delete the ghost items (IDs 54-60 which are all Product 209)
    $stmt = $pdo->prepare("DELETE FROM orders_item WHERE id IN (54, 55, 56, 57, 58, 59, 60)");
    $stmt->execute();
    $deletedCount = $stmt->rowCount();
    
    echo "Deleted $deletedCount ghost items (Item IDs 54-60)\n\n";
    
    // Show remaining items for affected orders
    $stmt = $pdo->query("
        SELECT oi.*, o.bill_no, p.name as product_name
        FROM orders_item oi
        LEFT JOIN orders o ON oi.order_id = o.id
        LEFT JOIN products p ON oi.product_id = p.id
        WHERE o.id IN (9, 10, 11, 12, 13, 14, 15)
        ORDER BY o.id, oi.id
    ");
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Remaining items for orders 9-15:\n";
    echo str_repeat("=", 80) . "\n";
    
    $currentOrderId = null;
    foreach ($items as $item) {
        if ($currentOrderId !== $item['order_id']) {
            if ($currentOrderId !== null) echo "\n";
            echo "\nOrder #{$item['bill_no']} (ID: {$item['order_id']})\n";
            echo str_repeat("-", 80) . "\n";
            $currentOrderId = $item['order_id'];
        }
        echo "  Item ID: {$item['id']} | Product: {$item['product_name']} | Qty: {$item['qty']}\n";
    }
    
    echo "\n\n✓ Ghost items removed successfully!\n";
    echo "Please test creating a new order to see if the issue persists.\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

echo "</pre>";
?>
