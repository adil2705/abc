<?php
require_once __DIR__ . '/../config/database.php';

// Try to find the specific order mentioned or fallback to the latest
$billNo = 'BILPR-20CD';
$stmt = $pdo->prepare("SELECT * FROM orders WHERE bill_no = ?");
$stmt->execute([$billNo]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "Order $billNo not found, checking latest order...<br>";
    $stmt = $pdo->query("SELECT * FROM orders ORDER BY id DESC LIMIT 1");
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (!$order) {
    die("No orders found in database.");
}

echo "<pre>";
echo "<strong>Order Details:</strong>\n";
print_r($order);

echo "\n<strong>Raw Orders Item Table (SELECT * FROM orders_item WHERE order_id = " . $order['id'] . "):</strong>\n";
$stmt = $pdo->prepare("SELECT * FROM orders_item WHERE order_id = ?");
$stmt->execute([$order['id']]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($items);

echo "\n<strong>Joined Query (used in admin/orders.php):</strong>\n";
$stmt = $pdo->prepare("
    SELECT oi.*, p.name as product_name, p.sku as product_sku
    FROM orders_item oi
    LEFT JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$stmt->execute([$order['id']]);
$joined = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($joined);

echo "</pre>";
?>
