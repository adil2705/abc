<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['token']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Token and password are required']);
    exit;
}

$token = $data['token'];
$password = $data['password'];

if (strlen($password) < 6) {
    http_response_code(400);
    echo json_encode(['error' => 'Password must be at least 6 characters']);
    exit;
}

try {
    // Find user with valid token and expiry
    $stmt = $pdo->prepare("SELECT id FROM buyers WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->execute([$token]);
    $user = $stmt->fetch();

    if (!$user) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid or expired token']);
        exit;
    }

    // Update password and clear token
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    $updateStmt = $pdo->prepare("UPDATE buyers SET password = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?");
    $updateStmt->execute([$hashedPassword, $user['id']]);

    http_response_code(200);
    echo json_encode(['message' => 'Password reset successfully']);

} catch (PDOException $e) {
    error_log("Reset Password Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to reset password']);
}
?>
