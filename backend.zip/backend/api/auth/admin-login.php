<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/jwt.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($data['username']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Username and password are required']);
    exit;
}

$username = trim($data['username']);
$password = $data['password'];

try {
    // Find admin user
    $stmt = $pdo->prepare("SELECT u.*, ug.group_id FROM users u 
                          LEFT JOIN user_group ug ON u.id = ug.user_id 
                          WHERE u.username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if (!$user) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid username or password']);
        exit;
    }
    
    // Verify password
    if (!password_verify($password, $user['password'])) {
        error_log("Login failed: Password mismatch for user " . $username);
        http_response_code(401);
        echo json_encode(['error' => 'Invalid username or password']);
        exit;
    }
    
    // Generate JWT token
    $token = JWT::encode([
        'user_id' => $user['id'],
        'username' => $user['username'],
        'is_admin' => true,
        'group_id' => $user['group_id'],
        'exp' => time() + (7 * 24 * 60 * 60) // 7 days
    ]);
    
    http_response_code(200);
    echo json_encode([
        'message' => 'Login successful',
        'token' => $token,
        'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'firstname' => $user['firstname'],
            'lastname' => $user['lastname'],
            'email' => $user['email'],
            'group_id' => $user['group_id']
        ]
    ]);
    
} catch (PDOException $e) {
    error_log("Login failed: Database error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Login failed']);
}
