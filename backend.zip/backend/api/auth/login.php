<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../utils/jwt.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($data['email']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and password are required']);
    exit;
}

$email = trim($data['email']);
$password = $data['password'];

try {
    // Find buyer by email
    $stmt = $pdo->prepare("SELECT * FROM buyers WHERE email = ?");
    $stmt->execute([$email]);
    $buyer = $stmt->fetch();
    
    if (!$buyer) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid email or password']);
        exit;
    }
    
    // Verify password
    if (!password_verify($password, $buyer['password'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid email or password']);
        exit;
    }
    
    // Generate JWT token
    $token = JWT::encode([
        'buyer_id' => $buyer['id'],
        'email' => $buyer['email'],
        'name' => $buyer['name'],
        'exp' => time() + (7 * 24 * 60 * 60) // 7 days
    ]);
    
    http_response_code(200);
    echo json_encode([
        'message' => 'Login successful',
        'token' => $token,
        'buyer' => [
            'id' => $buyer['id'],
            'name' => $buyer['name'],
            'email' => $buyer['email'],
            'phone' => $buyer['phone'],
            'address' => $buyer['address']
        ]
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Login failed']);
}
