<?php
require_once __DIR__ . '/../../config/cors.php';
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { // Using POST for update to handle potential non-standard PUT issues in some envs, or use PUT
    http_response_code(405);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'User ID required']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Update User Fields
    $sql = "UPDATE users SET username = ?, email = ?, firstname = ?, lastname = ?, phone = ?, gender = ?";
    $params = [
        $data['username'],
        $data['email'],
        $data['firstname'],
        $data['lastname'],
        $data['phone'],
        $data['gender']
    ];

    if (!empty($data['password'])) {
        $sql .= ", password = ?";
        $params[] = password_hash($data['password'], PASSWORD_DEFAULT);
    }

    $sql .= " WHERE id = ?";
    $params[] = $data['id'];

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    // Update Groups (Delete all and re-insert)
    if (isset($data['groups'])) { // Expecting array of group IDs
        $pdo->prepare("DELETE FROM user_group WHERE user_id = ?")->execute([$data['id']]);
        
        $stmtGroup = $pdo->prepare("INSERT INTO user_group (user_id, group_id) VALUES (?, ?)");
        foreach ($data['groups'] as $groupId) {
            $stmtGroup->execute([$data['id'], $groupId]);
        }
    }

    $pdo->commit();
    echo json_encode(['message' => 'User updated successfully']);

} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?>
