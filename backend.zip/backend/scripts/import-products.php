<?php
require_once __DIR__ . '/../config/database.php';

$csvFile = __DIR__ . '/item.csv';

if (!file_exists($csvFile)) {
    die("Error: item.csv not found. Please run 'node convert_xlsx.js' first.\n");
}

echo "Starting product import from item.csv...\n\n";

$file = fopen($csvFile, 'r');
// Get headers
$headers = fgetcsv($file);
// Expected: Brand Name, Product Name, MRP, Discount, Net Rate
// But we should map by index or just assume order if we know it.
// Let's assume the CSV structure matches the XLSX columns.
// Based on typical behavior, headers are the first row.

$imported = 0;
$errors = 0;
$skipped = 0;

try {
    $pdo->beginTransaction();

    // Prepare statements
    $checkBrand = $pdo->prepare("SELECT id FROM brands WHERE name = ?");
    $insertBrand = $pdo->prepare("INSERT INTO brands (name, active) VALUES (?, 1)");
    
    $checkProduct = $pdo->prepare("SELECT id FROM products WHERE name = ?");
    $insertProduct = $pdo->prepare("INSERT INTO products (
        name, sku, price, discount, qty, image, description, 
        attribute_value_id, brand_id, category_id, store_id, availability
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    while (($row = fgetcsv($file)) !== false) {
        // Skip empty rows
        if (empty($row[0])) continue;

        // Map columns (adjust indices based on actual CSV)
        // 0: Brand Name
        // 1: Product Name
        // 2: MRP
        // 3: Discount
        // 4: Net Rate
        
        $brandName = trim($row[0]);
        $productName = trim($row[1]);
        $mrp = floatval($row[2]);
        $discountRaw = $row[3]; // e.g., "22%" or 0.22
        $netRate = floatval($row[4]);
        
        // Sanitize Discount
        $discountVal = str_replace('%', '', $discountRaw);

        // Calculate Price: Use Net Rate if available, else MRP - Discount
        $price = $netRate > 0 ? $netRate : $mrp; // User asked for Net Rate likely as price

        // Find or Create Brand
        $checkBrand->execute([$brandName]);
        $brand = $checkBrand->fetch();
        if ($brand) {
            $brandId = $brand['id'];
        } else {
            $insertBrand->execute([$brandName]);
            $brandId = $pdo->lastInsertId();
        }

        // Check Product Duplication
        $checkProduct->execute([$productName]);
        if ($checkProduct->fetch()) {
            // echo "Skipping duplicate: $productName\n";
            $skipped++;
            continue;
        }

        // Insert Product
        // Generate SKU dynamically if not provided (using Product Name part)
        $sku = substr(str_replace(' ', '', $productName), 0, 10) . '-' . rand(100, 999);

        // Category: Default to 'OTHER' (ID 16 from sql dump) or logic to map?
        // User didn't specify category mapping.
        $categoryId = 16; 

        $insertProduct->execute([
            $productName,
            $sku,
            $price,
            $discountVal,
            100, // Default Qty
            '', // No image
            "<p>$productName</p>",
            'null',
            json_encode([(string)$brandId]), // brand_id as JSON array of strings
            json_encode([(string)$categoryId]), // category_id as JSON array
            3, // Store ID 3 (SANS Traders)
            1  // Availability
        ]);

        $imported++;
    }

    $pdo->commit();
    fclose($file);

    echo "Import completed!\n";
    echo "Total imported: $imported\n";
    echo "Duplicate/Skipped: $skipped\n";

} catch (Exception $e) {
    $pdo->rollBack();
    echo "Error: " . $e->getMessage() . "\n";
}
?>
